import 'package:RM_DAAPP/bm_model/user_model.dart';
import 'package:RM_DAAPP/bm_other/userDetails.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/bm_admin_dash.dart';
import 'package:RM_DAAPP/bm_approved_details/admin_approved_details_widget.dart';
import 'package:RM_DAAPP/bm_editdata.dart';
import 'package:RM_DAAPP/bm_model/pending_view_model.dart';
import 'package:RM_DAAPP/bm_other/common.dart';
import 'package:RM_DAAPP/bm_resumited_rm_bm.dart';
import 'package:RM_DAAPP/bm_widget/user_data_widget.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class ResubmittedDetails extends StatefulWidget {
  @override
  _ResubmittedDetailsState createState() => _ResubmittedDetailsState();
}

class _ResubmittedDetailsState extends State<ResubmittedDetails> {
  UserDetails userDetails = UserDetails();
  Future<List<PendingViewModel>> getPendingData(String userId) async {
    List<PendingViewModel> pendingList = [];
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var response = await http.get(
          "http://118.91.235.247/daapp/api/bm_resubmit_withlimit.php?admin_id=${userModel.userId}");
      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("With in Limit Resubmitted List"),
        backgroundColor: Colors.red,
      ),
      body: FutureBuilder(
        future: getPendingData(userData.userId),
        builder: (cont, AsyncSnapshot<List<PendingViewModel>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return Container(
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.data == null || snapshot.data.isEmpty) {
            return Container(
              child: Center(
                child: Text(
                  "Record not found...",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
            );
          }

          return ListView.builder(
              itemCount: snapshot.data.length,
              shrinkWrap: true,
              // physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                PendingViewModel pendingViewModel = snapshot.data[index];
                return InkWell(
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => resumited_rm_bm(
                          pendingViewModel: pendingViewModel,
                        ),
                      ),
                    ).then((value) {
                      setState(() {});
                    });
                  },
                  child: UserDataWidget(
                    pendingViewModel: pendingViewModel,
                    // onDelete: () {
                    // deletePendingData(
                    //     userData.userId, pendingViewModel.bookId);
                    // },
                  ),
                );
              });
        },
      ),
    );
  }
}
