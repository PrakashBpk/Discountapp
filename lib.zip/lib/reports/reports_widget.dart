import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:typed_data';

import 'package:RM_DAAPP/model/user_model.dart';
import 'package:RM_DAAPP/other/userDetails.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:RM_DAAPP/model/car_model_model.dart';
import 'package:RM_DAAPP/model/pending_model.dart';
import 'package:RM_DAAPP/model/pending_view_model.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:horizontal_data_table/horizontal_data_table.dart';
import 'package:http/http.dart';
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';

import 'package:csv/csv.dart';
import '../flutter_flow/flutter_flow_icon_button.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:ext_storage/ext_storage.dart' as ext;

class ReportsWidget extends StatefulWidget {
  const ReportsWidget({Key key}) : super(key: key);

  @override
  _ReportsWidgetState createState() => _ReportsWidgetState();
}

class _ReportsWidgetState extends State<ReportsWidget> {
  DateTime datePicked1;

  UserDetails userDetails = UserDetails();
  DateTime datePicked2;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  HDTRefreshController _hdtRefreshController = HDTRefreshController();
  Future<List<PendingViewModel>> _getReportData;
  List<CarModelModel> _carModelList = [];
  CarModelModel _selectedCarModel;
  List<PendingModel> _pendingModelList = [];
  PendingModel _selectedPending;
  TextEditingController dateinput1 = TextEditingController();
  TextEditingController dateinput2 = TextEditingController();
  Future getCarmodel() async {
    //http://192.168.68.105/API_FOlder/
    try {
      var url = "http://118.91.235.247/daapp/api/car_model.php";
      var response = await http.post(url);
      if (response.statusCode == 200) {
        _carModelList = carModelModelFromJson(response.body);
        setState(() {});
      }
    } catch (e) {
      _carModelList = [];
    }
  }

  @override
  void initState() {
    super.initState();
    dateinput1.text = "";
    dateinput2.text = ""; //set the initial value of text field
    _getReportData = getResponseData();
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      getCarmodel();
    });
    _pendingModelList.add(PendingModel(statusId: "1", statusName: "Pending"));
    _pendingModelList.add(PendingModel(statusId: "2", statusName: "Approved"));
    _pendingModelList.add(PendingModel(statusId: "3", statusName: "Denied"));
    _pendingModelList
        .add(PendingModel(statusId: "4", statusName: "Resubmitted"));
    _pendingModelList.add(PendingModel(statusId: "5", statusName: "Forwarded"));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.red[600],
        automaticallyImplyLeading: true,
        title: Text(
          'Reports',
          style: FlutterFlowTheme.bodyText1.override(
            fontFamily: 'Roboto',
            color: FlutterFlowTheme.tertiaryColor,
            fontSize: 25,
            fontWeight: FontWeight.w800,
          ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 4,
      ),
      backgroundColor: Color(0xFFEFE9E8),
      body: SafeArea(
        child: FutureBuilder<List<PendingViewModel>>(
            future: _getReportData,
            builder: (context, AsyncSnapshot<List<PendingViewModel>> snapshot) {
              if (snapshot.data == null) {
                return Container(
                  child: Center(child: CircularProgressIndicator()),
                );
              }

              if (snapshot.connectionState != ConnectionState.done) {
                return Container(
                  alignment: Alignment.center,
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              return SingleChildScrollView(
                child: Column(
                  children: [
                    Column(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(3, 0, 0, 0),
                                child: Text(
                                  'Request Raised',
                                  textAlign: TextAlign.start,
                                  style: FlutterFlowTheme.bodyText1.override(
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                                child: Container(
                                  width: 100,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEEEEEE),
                                    border: Border.all(
                                      color: Color(0xF50E0E0E),
                                    ),
                                  ),
                                  child: AutoSizeText(
                                    '${snapshot.data.length}',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                                child: Text(
                                  'Value',
                                  style: FlutterFlowTheme.bodyText1.override(
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(2, 0, 0, 0),
                                child: Container(
                                  width: 100,
                                  height: 20,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFEEEEEE),
                                    border: Border.all(
                                      color: Color(0xF50E0E0E),
                                    ),
                                  ),
                                  child: AutoSizeText(
                                    '${_getTotalDiscount(snapshot.data)}',
                                    textAlign: TextAlign.center,
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              /*  Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(3, 0, 0, 0),
                                child: Text(
                                  'Request Raised',
                                  textAlign: TextAlign.start,
                                  style: FlutterFlowTheme.bodyText1.override(
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ), */
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                                child: Container(
                                    width: 150,
                                    height: 30,
                                    decoration: BoxDecoration(
                                      color: Color(0xFFEEEEEE),
                                      border: Border.all(
                                        color: Color(0xF50E0E0E),
                                      ),
                                    ),
                                    child: TextField(
                                      controller:
                                          dateinput1, //editing controller of this TextField
                                      decoration: InputDecoration(
                                          icon: Icon(Icons
                                              .calendar_today), //icon of text field
                                          hintText:
                                              "Enter Start Date" //label text of field
                                          ),
                                      readOnly:
                                          true, //set it true, so that user will not able to edit text
                                      /*  onTap: () async {
                                DateTime pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(
                                        2000), //DateTime.now() - not to allow to choose before today.
                                    lastDate: DateTime(2101));*/
                                      onTap: () async {
                                        DateTime pickedDate =
                                            await DatePicker.showDatePicker(
                                          context,
                                          showTitleActions: true,
                                          onConfirm: (date) {
                                            setState(() => datePicked1 = date);
                                          },
                                          currentTime: getCurrentTimestamp,
                                        );

                                        if (pickedDate != null) {
                                          print(
                                              pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                          String formattedDate =
                                              DateFormat('yyyy-MM-dd')
                                                  .format(pickedDate);
                                          print(
                                              formattedDate); //formatted date output using intl package =>  2021-03-16
                                          //you can implement different kind of Date Format here according to your requirement

                                          setState(() {
                                            dateinput1.text =
                                                formattedDate; //set output date to TextField value.
                                          });
                                        } else {
                                          print("Date is not selected");
                                        }
                                      },
                                    )),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                                child: Text(
                                  'To',
                                  style: FlutterFlowTheme.bodyText1.override(
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(2, 0, 0, 0),
                                child: Container(
                                    width: 150,
                                    height: 30,
                                    decoration: BoxDecoration(
                                      color: Color(0xFFEEEEEE),
                                      border: Border.all(
                                        color: Color(0xF50E0E0E),
                                      ),
                                    ),
                                    child: TextField(
                                      controller:
                                          dateinput2, //editing controller of this TextField
                                      decoration: InputDecoration(
                                          icon: Icon(Icons
                                              .calendar_today), //icon of text field
                                          hintText:
                                              "Enter end Date" //label text of field
                                          ),
                                      readOnly:
                                          true, //set it true, so that user will not able to edit text
                                      /*  onTap: () async {
                                DateTime pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(
                                        2000), //DateTime.now() - not to allow to choose before today.
                                    lastDate: DateTime(2101));*/
                                      onTap: () async {
                                        DateTime pickedDate =
                                            await DatePicker.showDatePicker(
                                          context,
                                          showTitleActions: true,
                                          onConfirm: (date) {
                                            setState(() => datePicked2 = date);
                                          },
                                          currentTime: getCurrentTimestamp,
                                        );

                                        if (pickedDate != null) {
                                          print(
                                              pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                          String formattedDate =
                                              DateFormat('yyyy-MM-dd')
                                                  .format(pickedDate);
                                          print(
                                              formattedDate); //formatted date output using intl package =>  2021-03-16
                                          //you can implement different kind of Date Format here according to your requirement

                                          setState(() {
                                            dateinput2.text =
                                                formattedDate; //set output date to TextField value.
                                          });
                                        } else {
                                          print("Date is not selected");
                                        }
                                      },
                                    )),
                              ),
                            ],
                          ),
                        ),

                        // Padding(
                        //   padding: EdgeInsets.symmetric(horizontal: 5, vertical: 10),
                        //   child: Row(
                        //     children: [
                        //       Padding(
                        //         padding: EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                        //         child: Text(
                        //           'Unique Cars',
                        //           style: FlutterFlowTheme.bodyText1.override(
                        //             fontFamily: 'Roboto',
                        //           ),
                        //         ),
                        //       ),
                        //       Padding(
                        //         padding: EdgeInsetsDirectional.fromSTEB(3, 0, 0, 0),
                        //         child: Container(
                        //           width: 40,
                        //           height: 20,
                        //           decoration: BoxDecoration(
                        //             color: Color(0xFFEEEEEE),
                        //             border: Border.all(
                        //               color: Color(0xF50E0E0E),
                        //             ),
                        //           ),
                        //           child: AutoSizeText(
                        //             '2',
                        //             textAlign: TextAlign.center,
                        //             style: FlutterFlowTheme.bodyText1.override(
                        //               fontFamily: 'Roboto',
                        //               fontWeight: FontWeight.bold,
                        //             ),
                        //           ),
                        //         ),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                        Divider(
                          thickness: 2,
                          color: Color(0xFFEEDED6),
                        ),
                        /* Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Text(
                                'Date From ',
                                style: FlutterFlowTheme.bodyText1.override(
                                  fontFamily: 'Roboto',
                                ),
                              ),
                              FlutterFlowIconButton(
                                borderColor: Colors.transparent,
                                borderRadius: 30,
                                borderWidth: 1,
                                buttonSize: 50,
                                icon: Icon(
                                  Icons.date_range_outlined,
                                  color: Colors.black,
                                  size: 30,
                                ),
                                onPressed: () async {
                                  await DatePicker.showDatePicker(
                                    context,
                                    showTitleActions: true,
                                    onConfirm: (date) {
                                      setState(() => datePicked1 = date);
                                    },
                                    currentTime: getCurrentTimestamp,
                                  );
                                },
                              ),
                              Text(
                                'To',
                                style: FlutterFlowTheme.bodyText1,
                              ),
                              FlutterFlowIconButton(
                                borderColor: Colors.transparent,
                                borderRadius: 30,
                                borderWidth: 1,
                                buttonSize: 50,
                                icon: Icon(
                                  Icons.date_range_outlined,
                                  color: Colors.black,
                                  size: 30,
                                ),
                                onPressed: () async {
                                  await DatePicker.showDatePicker(
                                    context,
                                    showTitleActions: true,
                                    onConfirm: (date) {
                                      setState(() => datePicked2 = date);
                                    },
                                    currentTime: getCurrentTimestamp,
                                  );
                                },
                              ),
                            ],
                          ),
                        ), */
                        /*   Padding(
                            padding: EdgeInsets.all(15),
                            // height:150,
                            //child: Center(
                            child: ConstrainedBox(
                                constraints:
                                    BoxConstraints.tightFor(width: 150),
                                child: TextField(
                                  controller:
                                      dateinput1, //editing controller of this TextField
                                  decoration: InputDecoration(
                                      icon: Icon(Icons
                                          .calendar_today), //icon of text field
                                      labelText:
                                          "Enter Start Date" //label text of field
                                      ),
                                  readOnly:
                                      true, //set it true, so that user will not able to edit text
                                  /*  onTap: () async {
                                DateTime pickedDate = await showDatePicker(
                                    context: context,
                                    initialDate: DateTime.now(),
                                    firstDate: DateTime(
                                        2000), //DateTime.now() - not to allow to choose before today.
                                    lastDate: DateTime(2101));*/
                                  onTap: () async {
                                    DateTime pickedDate =
                                        await DatePicker.showDatePicker(
                                      context,
                                      showTitleActions: true,
                                      onConfirm: (date) {
                                        setState(() => datePicked1 = date);
                                      },
                                      currentTime: getCurrentTimestamp,
                                    );

                                    if (pickedDate != null) {
                                      print(
                                          pickedDate); //pickedDate output format => 2021-03-10 00:00:00.000
                                      String formattedDate =
                                          DateFormat('yyyy-MM-dd')
                                              .format(pickedDate);
                                      print(
                                          formattedDate); //formatted date output using intl package =>  2021-03-16
                                      //you can implement different kind of Date Format here according to your requirement

                                      setState(() {
                                        dateinput1.text =
                                            formattedDate; //set output date to TextField value.
                                      });
                                    } else {
                                      print("Date is not selected");
                                    }
                                  },
                                ))), */

                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                          child: Row(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                                child: Text(
                                  'Status',
                                  style: FlutterFlowTheme.bodyText1.override(
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ),
                              Container(
                                width: 100,
                                padding: EdgeInsets.symmetric(horizontal: 5),
                                margin: EdgeInsets.symmetric(horizontal: 5),
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    border: Border.all(color: Colors.black)),
                                child: DropdownButton<PendingModel>(
                                  isDense: true,
                                  isExpanded: true,
                                  hint: Text(
                                    "Select status",
                                    style: TextStyle(fontSize: 11),
                                  ),
                                  value: _selectedPending,
                                  underline: Container(),
                                  icon: Icon(Icons.keyboard_arrow_down),
                                  items: _pendingModelList.map((e) {
                                    return DropdownMenuItem(
                                        value: e,
                                        child: Text(
                                          e.statusName ?? "",
                                          style: TextStyle(
                                              fontWeight: FontWeight.w600,
                                              fontSize: 12),
                                        ));
                                  }).toList(),
                                  onChanged: (value) {
                                    _selectedPending = value;
                                    setState(() {});
                                  },
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(10, 0, 0, 0),
                                child: Text(
                                  'Car Model',
                                  style: FlutterFlowTheme.bodyText1.override(
                                    fontFamily: 'Roboto',
                                  ),
                                ),
                              ),
                              if (_carModelList.isNotEmpty)
                                Expanded(
                                  child: Container(
                                    padding:
                                        EdgeInsets.symmetric(horizontal: 5),
                                    margin: EdgeInsets.symmetric(horizontal: 5),
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        border:
                                            Border.all(color: Colors.black)),
                                    child: DropdownButton<CarModelModel>(
                                      //controller:requeststatus,
                                      hint: Text("Select the Car Model"),
                                      value: _selectedCarModel,
                                      isExpanded: true,
                                      underline: Container(),
                                      icon: Icon(Icons.keyboard_arrow_down),
                                      items: _carModelList.map((carmodel) {
                                        return DropdownMenuItem(
                                            value: carmodel,
                                            child: Text(
                                              carmodel.carModelName ?? "",
                                              style: TextStyle(
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 13),
                                            ));
                                      }).toList(),
                                      onChanged: (value) {
                                        _selectedCarModel = value;
                                        setState(() {});
                                      },
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                        // Padding(
                        //   padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                        //   child: Row(
                        //     mainAxisSize: MainAxisSize.max,
                        //     children: [
                        //       Text(
                        //         'User',
                        //         style: FlutterFlowTheme.bodyText1.override(
                        //           fontFamily: 'Roboto',
                        //         ),
                        //       ),
                        //       Padding(
                        //         padding:
                        //             EdgeInsetsDirectional.fromSTEB(12, 0, 0, 0),
                        //         child: FlutterFlowDropDown(
                        //           options: ['All User'].toList(),
                        //           onChanged: (val) =>
                        //               setState(() => dropDownValue3 = val),
                        //           width: 100,
                        //           height: 25,
                        //           textStyle:
                        //               FlutterFlowTheme.bodyText1.override(
                        //             fontFamily: 'Roboto',
                        //             color: Colors.black,
                        //           ),
                        //           fillColor: Colors.white,
                        //           elevation: 2,
                        //           borderColor: Color(0xFF080707),
                        //           borderWidth: 0,
                        //           borderRadius: 0,
                        //           margin: EdgeInsetsDirectional.fromSTEB(
                        //               12, 4, 12, 4),
                        //           hidesUnderline: true,
                        //         ),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                    Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      child: Row(
                        children: [
                          Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(80, 0, 0, 0),
                            child: FFButtonWidget(
                              onPressed: () {
                                _getReportData = getResponseData();
                                setState(() {});
                              },
                              text: 'Submit',
                              options: FFButtonOptions(
                                width: 80,
                                height: 30,
                                color: Colors.blue[600],
                                textStyle: FlutterFlowTheme.subtitle2.override(
                                  fontFamily: 'Roboto',
                                  color: Colors.white,
                                ),
                                borderSide: BorderSide(
                                  color: Colors.transparent,
                                  width: 1,
                                ),
                                borderRadius: 12,
                              ),
                            ),
                          ),
                          Padding(
                            padding:
                                EdgeInsetsDirectional.fromSTEB(15, 0, 0, 0),
                            child: FFButtonWidget(
                              onPressed: () {
                                print('Button pressed ...');
                                csvGenerate(list: snapshot.data);
                                pdfGenerate(list: snapshot.data);
                              },
                              text: 'Export to Csv',
                              options: FFButtonOptions(
                                width: 120,
                                height: 30,
                                color: Colors.blue[600],
                                textStyle: FlutterFlowTheme.subtitle2.override(
                                  fontFamily: 'Roboto',
                                  color: Colors.white,
                                ),
                                borderSide: BorderSide(
                                  color: Colors.transparent,
                                  width: 1,
                                ),
                                borderRadius: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    // Align(
                    //   alignment: AlignmentDirectional(-1, 1),
                    //   child: Padding(
                    //     padding: EdgeInsetsDirectional.fromSTEB(5, 10, 0, 0),
                    //     child: Container(
                    //       width: 400,
                    //       height: 530,
                    //       decoration: BoxDecoration(
                    //         color: Color(0xFFEEEEEE),
                    //         shape: BoxShape.rectangle,
                    //       ),
                    //       child: Padding(
                    //         padding: EdgeInsetsDirectional.fromSTEB(2, 15, 0, 0),
                    //         child: GridView(
                    //           padding: EdgeInsets.zero,
                    //           gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    //             crossAxisCount: 6,
                    //             crossAxisSpacing: 5,
                    //             mainAxisSpacing: 10,
                    //             childAspectRatio: 1,
                    //           ),
                    //           shrinkWrap: true,
                    //           scrollDirection: Axis.vertical,
                    //           children: [
                    //             Text(
                    //               'Booking ID',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //                 fontWeight: FontWeight.w900,
                    //               ),
                    //             ),
                    //             AutoSizeText(
                    //               'Customer Name',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //                 fontSize: 13,
                    //                 fontWeight: FontWeight.w900,
                    //               ),
                    //             ),
                    //             Padding(
                    //               padding: EdgeInsetsDirectional.fromSTEB(2, 0, 0, 0),
                    //               child: Text(
                    //                 'Status',
                    //                 textAlign: TextAlign.center,
                    //                 style: FlutterFlowTheme.bodyText1.override(
                    //                   fontFamily: 'Roboto',
                    //                   fontWeight: FontWeight.w900,
                    //                 ),
                    //               ),
                    //             ),
                    //             Text(
                    //               'Car Model',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //                 fontWeight: FontWeight.w900,
                    //               ),
                    //             ),
                    //             Text(
                    //               'Year Make',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //                 fontWeight: FontWeight.w900,
                    //               ),
                    //             ),
                    //             Padding(
                    //               padding: EdgeInsetsDirectional.fromSTEB(0, 0, 3, 0),
                    //               child: Text(
                    //                 'Value of Discount',
                    //                 textAlign: TextAlign.center,
                    //                 style: FlutterFlowTheme.bodyText1.override(
                    //                   fontFamily: 'Roboto',
                    //                   fontSize: 13,
                    //                   fontWeight: FontWeight.w900,
                    //                 ),
                    //               ),
                    //             ),
                    //             Text(
                    //               '001',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               'Yazhini',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               'Pending',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               'Swift',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               '2012',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               '2000',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Padding(
                    //               padding: EdgeInsetsDirectional.fromSTEB(5, 0, 0, 0),
                    //               child: Text(
                    //                 '002',
                    //                 textAlign: TextAlign.center,
                    //                 style: FlutterFlowTheme.bodyText1.override(
                    //                   fontFamily: 'Roboto',
                    //                 ),
                    //               ),
                    //             ),
                    //             Text(
                    //               'Praveen',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               'Pending',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               'Swift',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               '2008',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //             Text(
                    //               '3000',
                    //               textAlign: TextAlign.center,
                    //               style: FlutterFlowTheme.bodyText1.override(
                    //                 fontFamily: 'Roboto',
                    //               ),
                    //             ),
                    //           ],
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _tableTitleWidget(title: "Booking ID"),
                        _tableTitleWidget(title: "Excutive Name"),
                        _tableTitleWidget(title: "Status Changed By"),
                        //  _tableTitleWidget(title: "Approver Name"),
                        _tableTitleWidget(title: "Status"),
                        _tableTitleWidget(title: "Branch"),
                        _tableTitleWidget(title: "Car Model"),
                        _tableTitleWidget(title: "Year Make"),
                        _tableTitleWidget(title: "Value"),
                      ],
                    ),
                    SizedBox(height: 10),
                    ListView.builder(
                      itemCount: snapshot.data.length,
                      physics: NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        PendingViewModel resportResponse = snapshot.data[index];
                        return Row(
                          children: [
                            _tableBodyWidget(
                                title: resportResponse.bookId ?? ""),
                            // _tableBodyWidget(title: resportResponse.requestDate??""),
                            _tableBodyWidget(
                                title: resportResponse.userName ?? ""),

                            _tableBodyWidget(
                                title: resportResponse.Approvedby ?? ""),
                            _tableBodyWidget(
                                title: resportResponse.status ?? ""),

                            _tableBodyWidget(
                                title: resportResponse.branch ?? ""),
                            _tableBodyWidget(
                                title: resportResponse.carModel ?? ""),

                            _tableBodyWidget(
                                title: resportResponse.yearMake ?? ""),
                            _tableBodyWidget(
                                title: resportResponse.discount ?? ""),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              );
            }),
      ),
    );
  }

  Widget _tableTitleWidget({String title}) {
    return Expanded(
      child: Center(
        child: Text(
          title ?? "",
          textAlign: TextAlign.center,
          style: FlutterFlowTheme.bodyText1.override(
            fontFamily: 'Roboto',
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }

  Widget _tableBodyWidget({String title}) {
    return Expanded(
      child: Container(
        height: 50,
        child: Text(
          title ?? "",
          textAlign: TextAlign.center,
          style: FlutterFlowTheme.bodyText1.override(
            fontFamily: 'Roboto',
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }

  Widget _generateFirstColumnRow(BuildContext context, int index) {
    return Container(
      child: Text("user.userInfo[index].name"),
      width: 100,
      height: 52,
      padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
      alignment: Alignment.centerLeft,
    );
  }

  Widget _generateRightHandSideColumnRow(BuildContext context, int index) {
    return Row(
      children: <Widget>[
        Container(
          child: Row(
            children: <Widget>[
              Icon(false ? Icons.notifications_off : Icons.notifications_active,
                  color: true ? Colors.red : Colors.green),
              Text(true ? 'Disabled' : 'Active')
            ],
          ),
          width: 100,
          height: 52,
          padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
          alignment: Alignment.centerLeft,
        ),
        Container(
          child: Text("user.userInfo[index].phone"),
          width: 200,
          height: 52,
          padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
          alignment: Alignment.centerLeft,
        ),
        Container(
          child: Text("user.userInfo[index].registerDate"),
          width: 100,
          height: 52,
          padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
          alignment: Alignment.centerLeft,
        ),
        Container(
          child: Text("user.userInfo[index].terminationDate"),
          width: 200,
          height: 52,
          padding: EdgeInsets.fromLTRB(5, 0, 0, 0),
          alignment: Alignment.centerLeft,
        ),
      ],
    );
  }

  Future<List<PendingViewModel>> getResponseData() async {
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      Map<String, String> params = {};
      params["user_id"] = userModel.userId;
      if (datePicked1 != null) {
        params["from_date"] = DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime(
            datePicked1.year, datePicked1.month, datePicked1.day, 00, 00, 00));
      }
      if (datePicked2 != null) {
        params["to_date"] = DateFormat("yyyy-MM-dd HH:mm:ss").format(DateTime(
            datePicked2.year, datePicked2.month, datePicked2.day, 23, 59, 59));
      }
      if (_selectedCarModel != null) {
        params["car_model"] = _selectedCarModel.carModelId;
      }
      if (_selectedPending != null) {
        params["status"] = _selectedPending.statusId;
      }
      print("res ==>  $params");
      Response response = await http.post(
        Uri.parse("http://118.91.235.247/daapp/api/report.php"),
        body: params,
        headers: {"Content-Type": "application/x-www-form-urlencoded"},
      );
      var res = jsonDecode(response.body);
      print("res ==>  $res");
      return pendingViewModelFromJson(response.body);
    } catch (e) {
      log("message ==>  $e");
      return [];
    }
    return [];
  }

  String _getTotalDiscount(List<PendingViewModel> list) {
    double value = 0;
    list.forEach((element) {
      double val = 0;
      try {
        val = double.parse(element.discount);
        value = value + val;
      } catch (e) {}
    });

    return value.toString();
  }

  Future<void> csvGenerate({List<PendingViewModel> list}) async {
    var status = await Permission.storage.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(children: [
        Expanded(child: Text("Please allow permission")),
        InkWell(
            onTap: () {
              openAppSettings();
            },
            child: Text(
              "Allow",
              style:
                  TextStyle(fontWeight: FontWeight.w600, color: Colors.orange),
            ))
      ])));
      return;
    }

    List<List<String>> csvData = [
      [
        "Booking ID",
        "Excutive Name",
        "Status",
        "Status Change By",
        "Branch",
        "Car Model",
        "Year Make",
        "Value"
      ]
    ];

    for (int i = 0; i < list.length; i++) {
      csvData.add([
        list[i].bookId ?? "",
        list[i].userName ?? "",
        list[i].status ?? "",
        list[i].Approvedby ?? "",
        list[i].branch ?? "",
        list[i].carModel ?? "",
        list[i].yearMake ?? "",
        list[i].discount ?? ""
      ]);
    }

    String csvDataConvert = ListToCsvConverter().convert(csvData);

    String dir = await ext.ExtStorage.getExternalStoragePublicDirectory(
        ext.ExtStorage.DIRECTORY_DOWNLOADS);
    print("dir $dir");

    File f = File("$dir/daapp_${DateTime.now().millisecondsSinceEpoch}.csv");

    f.writeAsString(csvDataConvert);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Row(
            children: [Expanded(child: Text("Csv Download SuccessFully"))])));
  }

  Future<void> pdfGenerate({List<PendingViewModel> list}) async {
    var status = await Permission.storage.request();
    if (!status.isGranted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Row(children: [
        Expanded(child: Text("Please allow permission")),
        InkWell(
            onTap: () {
              openAppSettings();
            },
            child: Text(
              "Allow",
              style:
                  TextStyle(fontWeight: FontWeight.w600, color: Colors.orange),
            ))
      ])));
      return;
    }
    final pw.Document pdf = pw.Document();
    pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(children: [
            pw.Row(children: [
              _pdfTableTitleWidget(title: "Booking ID"),
              // _tableTitleWidget(title: "Date"),
              _pdfTableTitleWidget(title: "Excutive Name"),
              _pdfTableTitleWidget(title: "Status Changed By"),
              _pdfTableTitleWidget(title: "Status"),
              _pdfTableTitleWidget(title: "Branch"),
              _pdfTableTitleWidget(title: "Car Model"),
              _pdfTableTitleWidget(title: "Year Make"),
              _pdfTableTitleWidget(title: "Car Color"),
            ]),
            for (int i = 0; i < list.length; i++) ...[
              pw.Row(
                children: [
                  _pdfTableBodyWidget(title: list[i].bookId ?? ""),
                  // _tableBodyWidget(title: resportResponse.requestDate??""),
                  _pdfTableBodyWidget(title: list[i].userName ?? ""),
                  _pdfTableBodyWidget(title: list[i].Approvedby ?? ""),
                  _pdfTableBodyWidget(title: list[i].status ?? ""),
                  _pdfTableBodyWidget(title: list[i].branch ?? ""),
                  _pdfTableBodyWidget(title: list[i].carModel ?? ""),
                  _pdfTableBodyWidget(title: list[i].yearMake ?? ""),
                  _pdfTableBodyWidget(title: list[i].carColor ?? ""),
                ],
              )
            ]
          ]); // Center
        }));

    var path = await ext.ExtStorage.getExternalStoragePublicDirectory(
        ext.ExtStorage.DIRECTORY_DOWNLOADS);
    String tempPath = path;
    final file =
        File("$tempPath/daapp_${DateTime.now().millisecondsSinceEpoch}.pdf");
    await file.writeAsBytes(await pdf.save());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content:
            Row(children: [Expanded(child: Text("Download SuccessFully"))])));
  }

  pw.Widget _pdfTableTitleWidget({String title}) {
    return pw.Expanded(
      child: pw.Center(
        child: pw.Text(
          title ?? "",
          textAlign: pw.TextAlign.center,
          style: pw.TextStyle(
            fontWeight: pw.FontWeight.bold,
          ),
        ),
      ),
    );
  }

  pw.Widget _pdfTableBodyWidget({String title}) {
    return pw.Expanded(
      child: pw.Container(
        height: 150,
        child: pw.Text(
          title ?? "",
          textAlign: pw.TextAlign.center,
          style: pw.TextStyle(
            fontWeight: pw.FontWeight.normal,
          ),
        ),
      ),
    );
  }
}
