import 'package:ext_storage/ext_storage.dart';
import 'package:pdf/pdf.dart';
import 'dart:io';
import 'package:pdf/widgets.dart ';
import 'package:path_provider/path_provider.dart';
//import 'package:sweetalert/sweetalert.dart';

reportView(
    header, formdata, MappingData, ExtFilenameasString, exportfilename) async {
  final Document pdf = Document();
  print(header);
  List<List<String>> DataList = new List();
  List<String> headerList = new List();
  for (var i = 0; i < header.length; i++) {
    headerList.add(header[i]['sTitle']);
  }

  for (int i = 0; i < formdata.length; i++) {
    var k = 0;
    List<String> recind = [];
    formdata[i].forEach((key, value) {
      recind.add(formdata[i][MappingData[k]]);
      k++;
    });
    DataList.add(recind);
  }
  DataList.insert(0, headerList);
  print(DataList);
//   print(headerList);
  pdf.addPage(MultiPage(
//      pageFormat:PdfPageFormat.letter.copyWith(marginBottom: 1 * PdfPageFormat.cm),
      pageFormat: PdfPageFormat.a4,
      crossAxisAlignment: CrossAxisAlignment.start,
      header: (Context context) {
        if (context.pageNumber == 1) {
          return null;
        }
        return Container(

//            color:  PdfColors.blue,
//            alignment: Alignment.centerRight,
            margin: const EdgeInsets.only(bottom: 3.0 * PdfPageFormat.mm),
            padding: const EdgeInsets.only(bottom: 3.0 * PdfPageFormat.mm),
            decoration: BoxDecoration(
                color: PdfColors.blue,
//                border:BoxBorder(bottom: true, width: 0.5, color: PdfColors.grey)
                border: Border.all(color: PdfColors.blueAccent)),
            child: Align(
              alignment: Alignment.center,
              child: Text('Pdf Genrator In tabular form',
                  textAlign: TextAlign.center,
                  textScaleFactor: 2,
                  style: TextStyle(color: PdfColors.white)),
            ));
      },
      footer: (Context context) {
        return Container(
            alignment: Alignment.centerRight,
            margin: const EdgeInsets.only(top: 1.0 * PdfPageFormat.cm),
            child: Text('Page ${context.pageNumber} of ${context.pagesCount}',
                style: Theme.of(context)
                    .defaultTextStyle
                    .copyWith(color: PdfColors.grey)));
      },
      build: (Context context) => <Widget>[
            Header(
                level: 0,
                child: Container(
                    margin:
                        const EdgeInsets.only(bottom: 3.0 * PdfPageFormat.mm),
                    padding:
                        const EdgeInsets.only(bottom: 3.0 * PdfPageFormat.mm),
                    decoration: BoxDecoration(
                        color: PdfColors.blue,
//                border:BoxBorder(bottom: true, width: 0.5, color: PdfColors.grey)
                        border: Border.all(color: PdfColors.blueAccent)),

//                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    child: Align(
                      alignment: Alignment.center,
                      child: Text('Pdf Genrator In tabular form',
                          textAlign: TextAlign.center,
                          textScaleFactor: 2,
                          style: TextStyle(color: PdfColors.white)),
                    ))),
            Header(level: 1, text: "$exportfilename List"),
            Padding(padding: const EdgeInsets.all(10)),
            Table.fromTextArray(context: context, data: DataList),
          ]));
  //save PDF

//Save and dispose the PDF document

  String path = await ExtStorage.getExternalStoragePublicDirectory(
      ExtStorage.DIRECTORY_DOWNLOADS);
  print(path);
  String Filepath = '$path/$ExtFilenameasString.pdf';
  File file = await File(Filepath);

  await file.writeAsBytes(await pdf.save());

//    document.dispose();
}
