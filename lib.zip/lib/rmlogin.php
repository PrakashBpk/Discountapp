<?php
include('config/connection.php');

$bookingid = $_POST['request_booking_id'];
$request_denied_discount = $_POST['request_denied_discount'];
$req_denied_comment = $_POST['req_denied_comment'];
$requestUpdatedOn=date('Y-m-d H:i:s');
//$request_status = $_POST['request_status'];

$check_discount = "SELECT * FROM requests WHERE request_booking_id = '$book_id'";
$check_discount_result = mysqli_query($conn,$check_discount);
$row = mysqli_fetch_assoc($check_discount_result);

if($row['req_denied_comment'] == '')
{
$sql_denied = "UPDATE requests SET request_revised_discount = '$request_denied_discount', req_denied_comment = '$req_denied_comment', request_status = 2 , request_updated_on = '$requestUpdatedOn' WHERE request_booking_id = '$bookingid'";
}
else
{
	$upd_req['message'] = 'Request discount already Updated';
	$upd_req['response'] = 'failed';
	echo json_encode($upd_req,JSON_PRETTY_PRINT);
	exit;
}
if(mysqli_query($conn,$sql_denied))
{
	$upd_req['message'] = 'Request Revised';
	$upd_req['response'] = 'success';
}
else
{
	$upd_req['message'] = 'Request not Revised';
	$upd_req['response'] = 'failed';
}

echo json_encode($upd_req,JSON_PRETTY_PRINT);

?>
