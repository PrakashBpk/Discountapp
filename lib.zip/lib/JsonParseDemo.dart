import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/loginchoice.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/Login.dart';
import 'package:RM_DAAPP/approveddetails.dart';
import 'package:RM_DAAPP/denieddetails.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_theme.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_widgets.dart';
import 'package:RM_DAAPP/forwarddetails.dart';
import 'package:RM_DAAPP/model/car_colour_model.dart';
import 'package:RM_DAAPP/model/car_model_model.dart';
import 'package:RM_DAAPP/model/current_offer_model.dart';
import 'package:RM_DAAPP/model/pending_model.dart';
import 'package:RM_DAAPP/model/year_make_model.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/pending_user/pending_user_widget.dart';
import 'package:RM_DAAPP/pendingdetails.dart';
import 'package:RM_DAAPP/reports/reports_widget.dart';
import 'package:RM_DAAPP/revised_user/revised_user_widget.dart';
import 'package:RM_DAAPP/reviseddetails.dart';
import 'package:flutter_session/flutter_session.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';
import 'package:page_transition/page_transition.dart';
import 'approved_list/approved_list_widget.dart';
import 'deleted_user/deleted_user_widget.dart';
import 'forward_user/forward_user_widget.dart';
import 'model/branch_model.dart';
import 'model/dashBoardModel.dart';
import 'other/userDetails.dart';
import 'reports/admin_reports_widget.dart';
import 'services.dart';
import 'Users.dart';
import 'package:http/http.dart' as http;

/* main() {
  const oneSec = Duration(seconds: 1);
  Timer.periodic(oneSec, (Timer t) => print('hi!'));
} */

class JsonParseDemo extends StatefulWidget {
  //
  JsonParseDemo() : super();

  @override
  _JsonParseDemoState createState() => _JsonParseDemoState();
}

class _JsonParseDemoState extends State<JsonParseDemo> {
  //
  Timer timer;
  bool _loading;
  List<DashBoardModel> _users;
  DashBoardModel _dashBoardModel = DashBoardModel();
  List<BranchModel> _branchList = [];
  List<CurrentOfferModel> _currentOfferList = [];
  List<CarModelModel> _carModelList = [];
  List<CarColourModel> _carColorList = [];
  List<YearMakeModel> _yearMakeList = [];
  CurrentOfferModel _selectedCurrentOffer;
  CarColourModel _selectedCarColor;
  BranchModel _selectedBranch;
  YearMakeModel _selectedYearMake;
  CarModelModel _selectedCarModel;
  bool _isLoading = false;
  List<PendingModel> _existingCustomer = [];
  PendingModel _selectedExistingCustomer;
  TextEditingController bookingId = new TextEditingController();
  TextEditingController cname = new TextEditingController();
  TextEditingController salesExecutiveController = new TextEditingController();
  TextEditingController referredcustomer = new TextEditingController();
  TextEditingController referrername = new TextEditingController();
  TextEditingController _discoutTextEditingController =
      new TextEditingController();

  Future getDashBoardData() async {
    try {
      var url =
          "http://118.91.235.247/daapp/api/admin_dashboard.php?admin_id=${userData.userId}";
      var response = await http.get(url);

      log("response ===>   ${response.body}");
      if (response.statusCode == 200) {
        _dashBoardModel = dashBoardModelFromJson(response.body);
        setState(() {});
      }
    } catch (e) {
      _dashBoardModel = DashBoardModel();
    }
  }

  Future sendmail() async {
    if (bookingId.text.isEmpty) {
      showSnack(context: context, msg: "Please enter bookingId");
      return;
    }

    if (cname.text.isEmpty) {
      showSnack(context: context, msg: "Please enter customer name");
      return;
    }

    if (_selectedBranch == null) {
      showSnack(context: context, msg: "Please select branch");
      return;
    }

    if (_selectedCarModel == null) {
      showSnack(context: context, msg: "Please select carModel");
      return;
    }
    if (_selectedYearMake == null) {
      showSnack(context: context, msg: "Please select carMakeYear");
      return;
    }
    if (_selectedCarColor == null) {
      showSnack(context: context, msg: "Please select car color");
      return;
    }
    if (_discoutTextEditingController.text.isEmpty) {
      showSnack(context: context, msg: "Please enter discount");
      return;
    }
    if (_existingCustomer == null) {
      showSnack(context: context, msg: "Please select existing customer");
      return;
    }
    _isLoading = true;
    setState(() {});
    removeFocus();
    var url = Uri.parse("http://118.91.235.247/daapp/api/request_add.php");
    var response = await http.post(url, body: {
      "booking_id": bookingId.text,
      "cust_name": cname.text,
      "user_id": userData.userId,
      "branch": _selectedBranch.branchId,
      "car_model": _selectedCarModel.carModelId,
      "year_make": _selectedYearMake.yearMakeId,
      "car_color": _selectedCarColor.carColorId,
      "offer": _selectedCurrentOffer.offerId,
      "discount": _discoutTextEditingController.text,
      "existing_cust": _selectedExistingCustomer.statusId
    });

    log("message======>   ${response.body}");
    var data = jsonDecode(response.body);
    if (data["response"] != "success") {
      Fluttertoast.showToast(
          msg: "Request already exist!",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER);
    } else {
      await FlutterSession().set('token', cname.text);
      Fluttertoast.showToast(
          msg: "Request Saved Successful",
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER);

      String username = 'geekdinoabt@gmail.com';
      String password = 'ityqalqiqhuzbola';
      String domainSmtp = 'smtp.gmail.com';

      //also use for gmail smtp
      //final smtpServer = gmail(username, password);

      //user for your own domain
      final smtpServer = SmtpServer(domainSmtp,
          username: username, password: password, port: 587);

      final message = Message()
        ..from = Address(
            username, 'New Request from ${salesExecutiveController.text}')
        ..recipients.add('prakashkumar@geekdino.com')
        ..subject = 'New Request Submitted'
        ..text = ''
        ..html =
            "<p>Booking_Id: ${bookingId.text}</p>\n<p>Name: ${cname.text}</p>\n <p>Field Sales Executive name: ${salesExecutiveController.text}</p> \n <p>Branch: ${_selectedBranch.branchName}</p> \n <p>Car Model: ${_selectedCarModel.carModelName}</p> \n <p>year make: ${_selectedYearMake.yearMakeName}</p> \n \n <p>Current Offer: ${_selectedCurrentOffer.offerName}</p> \n <p>Discount Value: ${_discoutTextEditingController.text}</p>";

      try {
        final sendReport = await send(message, smtpServer);
        print('Message sent: ' + sendReport.toString());
      } on MailerException catch (e) {
        print('Message not sent.');
        for (var p in e.problems) {
          print('Problem: ${p.code}: ${p.msg}');
        }
      }

      clearText();
      await getDashBoardData();
      _isLoading = false;
      setState(() {});
      await Navigator.push(
        context,
        PageTransition(
          type: PageTransitionType.fade,
          duration: Duration(milliseconds: 0),
          reverseDuration: Duration(milliseconds: 0),
          child: PendingDetails(),
        ),
      );
    }
  }

  void clearText() {
    bookingId.clear();
    cname.clear();
    referredcustomer.clear();
    referrername.clear();
    _selectedBranch = null;
    _selectedCarModel = null;
    _selectedYearMake = null;
    _selectedCarColor = null;
    _selectedCurrentOffer = null;
    _discoutTextEditingController.text = "";
    _selectedExistingCustomer = null;
  }

  Future getBranch() async {
    //http://192.168.68.105/API_FOlder/
    var url = "http://118.91.235.247/daapp/api/branch.php";
    var response = await http.get(url);

    if (response.statusCode == 200) {
      _branchList = branchModelFromJson(response.body);
      setState(() {});
    }
  }

  Future getCarmodel() async {
    //http://192.168.68.105/API_FOlder/
    var url = "http://118.91.235.247/daapp/api/car_model.php";
    var response = await http.get(url);

    if (response.statusCode == 200) {
      var jsonData = json.decode(response.body);
      _carModelList = carModelModelFromJson(response.body);
      setState(() {});
    }
  }

  Future getCurrentOffer() async {
    try {
      var url = "http://118.91.235.247/daapp/api/current_offer.php";
      var response = await http.get(url);

      if (response.statusCode == 200) {
        setState(() {
          _currentOfferList = currentOfferModelFromJson(response.body);
        });
      }
    } catch (e) {
      _currentOfferList = [];
    }
  }

  Future getCarColor() async {
    try {
      var url = "http://118.91.235.247/daapp/api/car_color.php";
      var response = await http.get(url);

      if (response.statusCode == 200) {
        setState(() {
          _carColorList = carColourModelFromJson(response.body);
        });
      }
    } catch (e) {
      _carColorList = [];
    }
  }

  Future getYearMake() async {
    try {
      var url = "http://118.91.235.247/daapp/api/year_make.php";
      var response = await http.get(url);

      if (response.statusCode == 200) {
        setState(() {
          _yearMakeList = yearMakeModelFromJson(response.body);
        });
      }
    } catch (e) {
      _yearMakeList = [];
    }
  }

  @override
  void initState() {
    super.initState();
    getDashBoardData();
    /*  main();
    timer = Timer.periodic(Duration(seconds: 2), (Timer t) => JsonParseDemo()); */
    _existingCustomer.add(PendingModel(statusName: "Yes", statusId: "1"));
    _existingCustomer.add(PendingModel(statusName: "No", statusId: "0"));
    getBranch();
    getCarmodel();
    getCurrentOffer();
    getCarColor();
    getYearMake();
    // getDashBoardData();
    salesExecutiveController.text = userData.userName;
    timer = Timer.periodic(
      Duration(seconds: 3),
      (Timer t) => getDashBoardData().then((users) {
        setState(() {
          _users = users;

          _loading = false;
        });
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    var choiceAction;
    var orientation;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.red,
        automaticallyImplyLeading: true,
        title: Text(
          'DAAPP',
          style: FlutterFlowTheme.title1.override(
            fontFamily: 'Roboto',
            color: FlutterFlowTheme.tertiaryColor,
            fontWeight: FontWeight.w800,
          ),
        ),
        actions: [
          IconButton(
              onPressed: () async {
                await UserDetails().logoutUser();
                Navigator.pushAndRemoveUntil(context,
                    MaterialPageRoute(builder: (cont) {
                  return loginchoicescreen();
                }), (route) => false);
              },
              icon: Icon(Icons.logout))
        ],
        centerTitle: true,
        elevation: 4,
      ),
      backgroundColor: Colors.red,
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Expanded(
              child: DefaultTabController(
                length: 2,
                initialIndex: 0,
                child: Column(
                  children: [
                    TabBar(
                      isScrollable: true,
                      labelColor: Colors.white,
                      labelStyle: FlutterFlowTheme.title2.override(
                        fontFamily: 'Roboto',
                      ),
                      indicatorColor: Colors.white,
                      tabs: [
                        Tab(
                          text: 'Request Form',
                        ),
                        Tab(
                          text: 'Dashboard',
                        )
                      ],
                    ),
                    Expanded(
                      child: TabBarView(
                        children: [
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              color: Colors.white,
                            ),
                            child: SingleChildScrollView(
                              child: Column(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          controller: bookingId,
                                          obscureText: false,
                                          decoration: InputDecoration(
                                            labelText: 'Booking ID',
                                            labelStyle: FlutterFlowTheme
                                                .subtitle2
                                                .override(
                                              fontFamily: 'Roboto',
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                          ),
                                          style: FlutterFlowTheme.subtitle2
                                              .override(
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          controller: cname,
                                          obscureText: false,
                                          decoration: InputDecoration(
                                            labelText: 'Customer Name',
                                            labelStyle: FlutterFlowTheme
                                                .subtitle2
                                                .override(
                                              fontFamily: 'Roboto',
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                          ),
                                          style: FlutterFlowTheme.subtitle2
                                              .override(
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          controller: salesExecutiveController,
                                          readOnly: true,
                                          decoration: InputDecoration(
                                            labelText: 'Sales Executive Name',
                                            labelStyle: FlutterFlowTheme
                                                .subtitle2
                                                .override(
                                              fontFamily: 'Roboto',
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                          ),
                                          style: FlutterFlowTheme.subtitle2
                                              .override(
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  DropdownButton<BranchModel>(
                                    isExpanded: true,
                                    hint: Text("Select the Branch"),
                                    value: _selectedBranch,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                    onTap: removeFocus,
                                    items: _branchList.map((branch) {
                                      return DropdownMenuItem(
                                          value: branch,
                                          child: Text(branch.branchName ?? ""));
                                    }).toList(),
                                    onChanged: (value) {
                                      setState(() {
                                        _selectedBranch = value;
                                      });
                                    },
                                  ),
                                  DropdownButton<CarModelModel>(
                                    //controller:requeststatus,
                                    isExpanded: true,
                                    hint: Text("Select the Car Model"),
                                    value: _selectedCarModel,
                                    onTap: removeFocus,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                    items: _carModelList.map((carmodel) {
                                      return DropdownMenuItem(
                                          value: carmodel,
                                          child: Text(
                                              carmodel.carModelName ?? ""));
                                    }).toList(),
                                    onChanged: (value) {
                                      _selectedCarModel = value;
                                      setState(() {});
                                    },
                                  ),
                                  DropdownButton<YearMakeModel>(
                                    //controller:requeststatus,
                                    isExpanded: true,
                                    hint: Text("Select make year"),
                                    value: _selectedYearMake,
                                    onTap: removeFocus,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                    items: _yearMakeList.map((element) {
                                      return DropdownMenuItem(
                                          value: element,
                                          child:
                                              Text(element.yearMakeName ?? ""));
                                    }).toList(),
                                    onChanged: (Value) {
                                      _selectedYearMake = Value;
                                      setState(() {});
                                    },
                                  ),
                                  DropdownButton<CarColourModel>(
                                    isExpanded: true,
                                    hint: Text("Select car color"),
                                    value: _selectedCarColor,
                                    onTap: removeFocus,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                    items: _carColorList.map((e) {
                                      return DropdownMenuItem(
                                          value: e,
                                          child: Text(e.carColorName ?? ""));
                                    }).toList(),
                                    onChanged: (s) {
                                      _selectedCarColor = s;
                                      setState(() {});
                                    },
                                  ),
                                  DropdownButton<CurrentOfferModel>(
                                    isExpanded: true,
                                    hint: Text("Select the Current offer"),
                                    value: _selectedCurrentOffer,
                                    onTap: removeFocus,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                    items: _currentOfferList.map((e) {
                                      return DropdownMenuItem(
                                          value: e,
                                          child: Text(e.offerName ?? ""));
                                    }).toList(),
                                    onChanged: (s) {
                                      _selectedCurrentOffer = s;
                                      setState(() {});
                                    },
                                  ),
                                  TextFormField(
                                    controller: _discoutTextEditingController,
                                    obscureText: false,
                                    decoration: InputDecoration(
                                      labelText: 'Enter Discount',
                                      labelStyle:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                      ),
                                      enabledBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Color(0x00000000),
                                          width: 1,
                                        ),
                                        borderRadius: const BorderRadius.only(
                                          topLeft: Radius.circular(4.0),
                                          topRight: Radius.circular(4.0),
                                        ),
                                      ),
                                      focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(
                                          color: Color(0x00000000),
                                          width: 1,
                                        ),
                                        borderRadius: const BorderRadius.only(
                                          topLeft: Radius.circular(4.0),
                                          topRight: Radius.circular(4.0),
                                        ),
                                      ),
                                    ),
                                    style: FlutterFlowTheme.subtitle2.override(
                                      fontFamily: 'Roboto',
                                    ),
                                    keyboardType: TextInputType.number,
                                  ),
                                  DropdownButton<PendingModel>(
                                    isExpanded: true,
                                    hint:
                                        Text("Select existing customer or new"),
                                    value: _selectedExistingCustomer,
                                    onTap: removeFocus,
                                    icon: Icon(Icons.keyboard_arrow_down),
                                    items: _existingCustomer.map((e) {
                                      return DropdownMenuItem(
                                          value: e,
                                          child: Text(e.statusName ?? ""));
                                    }).toList(),
                                    onChanged: (s) {
                                      _selectedExistingCustomer = s;
                                      setState(() {});
                                    },
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          controller: referredcustomer,
                                          obscureText: false,
                                          decoration: InputDecoration(
                                            labelText:
                                                'Are you Referred Customer ',
                                            labelStyle: FlutterFlowTheme
                                                .subtitle2
                                                .override(
                                              fontFamily: 'Roboto',
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                          ),
                                          style: FlutterFlowTheme.subtitle2
                                              .override(
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Row(
                                    mainAxisSize: MainAxisSize.max,
                                    children: [
                                      Expanded(
                                        child: TextFormField(
                                          controller: referrername,
                                          obscureText: false,
                                          decoration: InputDecoration(
                                            labelText: 'Referrer Name',
                                            labelStyle: FlutterFlowTheme
                                                .subtitle2
                                                .override(
                                              fontFamily: 'Roboto',
                                            ),
                                            enabledBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                            focusedBorder: UnderlineInputBorder(
                                              borderSide: BorderSide(
                                                color: Color(0x00000000),
                                                width: 1,
                                              ),
                                              borderRadius:
                                                  const BorderRadius.only(
                                                topLeft: Radius.circular(4.0),
                                                topRight: Radius.circular(4.0),
                                              ),
                                            ),
                                          ),
                                          style: FlutterFlowTheme.subtitle2
                                              .override(
                                            fontFamily: 'Roboto',
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(vertical: 20),
                                    child: FFButtonWidget(
                                      onPressed: _isLoading
                                          ? null
                                          : () async {
                                              sendmail();
                                            },
                                      text: 'Submit',
                                      options: FFButtonOptions(
                                        width: 130,
                                        height: 40,
                                        color: _isLoading
                                            ? Colors.grey
                                            : Colors.red,
                                        textStyle:
                                            FlutterFlowTheme.subtitle2.override(
                                          fontFamily: 'Roboto',
                                          color: Colors.white,
                                        ),
                                        borderSide: BorderSide(
                                          color: Colors.transparent,
                                          width: 1,
                                        ),
                                        borderRadius: 12,
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              color: Color(0xFFEEEEEE),
                            ),
                            child: Container(
                              color: Colors.white,
                              height: double.infinity,
                              padding: const EdgeInsets.all(10),
                              // child: GridView.builder(
                              //     // itemCount: 20,
                              //     gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
                              //         crossAxisCount:
                              //             (orientation == Orientation.portrait) ? 2 : 2),
                              //     itemCount: null == _users ? 0 : _users.length,
                              //     itemBuilder: (context, index) {
                              //       User user = _users[index];
                              //       return new GestureDetector(
                              //         child: new Card(
                              //           color: RandomColorModel().getColor(),
                              //           elevation: 0.0,
                              //           shape: const RoundedRectangleBorder(
                              //               borderRadius: BorderRadius.only(
                              //             topLeft: Radius.circular(20.0),
                              //             bottomLeft: Radius.circular(20.0),
                              //             topRight: Radius.circular(20.0),
                              //             bottomRight: Radius.circular(20.0),
                              //           )),
                              //           child: ListTile(
                              //             leading: Icon(Icons.analytics_rounded, size: 45),
                              //             title: Text(user.requeststatus),
                              //             subtitle: Text(user.count),
                              //           ),
                              //           /* child: GridTile(
                              //               footer: Text(user.count,
                              //                   textAlign: TextAlign.center,
                              //                   style: TextStyle(
                              //                       color: Colors.grey[800],
                              //                       fontWeight: FontWeight.bold,
                              //                       fontSize: 50)),
                              //               //new chil:Tex,
                              //               child: Text(user.requeststatus.toUpperCase(),
                              //                   textAlign: TextAlign.center,
                              //                   style: TextStyle(
                              //                       color: Colors.grey[800],
                              //                       fontFamily: 'helvetica_neue_medium',
                              //                       fontWeight: FontWeight.bold,
                              //                       fontSize: 30)),
                              //
                              //               /* onTap: () {
                              //           Navigator.push(context,
                              //               MaterialPageRoute(builder: (_) => adminDash()));
                              //         },  */
                              //             ) */
                              //         ),
                              //         onTap: () {
                              //           switch (user.requeststatus.toLowerCase()) {
                              //             case "denied":
                              //               {
                              //                 Navigator.push(
                              //                     context,
                              //                     MaterialPageRoute(
                              //                         builder: (_) => DeniedDetails()));
                              //               }
                              //               break;
                              //             case "approved":
                              //               {
                              //                 Navigator.push(
                              //                     context,
                              //                     MaterialPageRoute(
                              //                         builder: (_) => ApprovedDetails()));
                              //               }
                              //               break;
                              //             case "revised":
                              //               {
                              //                 Navigator.push(
                              //                     context,
                              //                     MaterialPageRoute(
                              //                         builder: (_) => RevisedDetails()));
                              //               }
                              //               break;
                              //             case "pending":
                              //               {
                              //                 Navigator.push(
                              //                     context,
                              //                     MaterialPageRoute(
                              //                         builder: (_) => PendingDetails()));
                              //               }
                              //               break;
                              //             case "approved":
                              //               {
                              //                 Navigator.push(context,
                              //                     MaterialPageRoute(builder: (_) => adminDash()));
                              //               }
                              //               break;
                              //             case "forward":
                              //               {
                              //                 Navigator.push(
                              //                     context,
                              //                     MaterialPageRoute(
                              //                         builder: (_) => ForwardDetails()));
                              //               }
                              //               break;
                              //             default:
                              //               break;
                              //           }
                              //           /*  showDialog(
                              //       builder: (context) => new CupertinoAlertDialog(
                              //         title: new Column(
                              //           children: <Widget>[
                              //             new Text("GridView"),
                              //             new Icon(
                              //               Icons.favorite,
                              //               color: Colors.green,
                              //             ),
                              //           ],
                              //         ),
                              //         content: new Text("Selected Item $index"),
                              //         actions: <Widget>[
                              //           new FlatButton(
                              //               onPressed: () {
                              //                 Navigator.of(context).pop();
                              //               },
                              //               child: new Text("OK"))
                              //         ],
                              //       ),
                              //       barrierDismissible: false,
                              //       context: context,
                              //     ); */
                              //         },
                              //       );
                              //     }),
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    SizedBox(height: 10),
                                    Text(
                                        "Total Request ${totalRequestCount()}"),
                                    GridView(
                                      padding: EdgeInsets.zero,
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      gridDelegate:
                                          SliverGridDelegateWithFixedCrossAxisCount(
                                        crossAxisCount: 2,
                                        crossAxisSpacing: 4,
                                        mainAxisSpacing: 10,
                                        childAspectRatio: 1,
                                      ),
                                      scrollDirection: Axis.vertical,
                                      children: [
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  5, 15, 0, 0),
                                          child: InkWell(
                                            onTap: () async {
                                              // await Navigator.push(
                                              //   context,
                                              //   MaterialPageRoute(
                                              //     builder: (context) =>
                                              //         PendingUserWidget(),
                                              //   ),
                                              // );
                                              await Navigator.push(
                                                context,
                                                PageTransition(
                                                  type: PageTransitionType.fade,
                                                  duration:
                                                      Duration(milliseconds: 0),
                                                  reverseDuration:
                                                      Duration(milliseconds: 0),
                                                  child: PendingDetails(),
                                                ),
                                              ).then((value) =>
                                                  getDashBoardData());
                                            },
                                            child: Card(
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              color: Color(0xE8E9A6DE),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 30, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Icon(
                                                          Icons.pending_actions,
                                                          color: FlutterFlowTheme
                                                              .tertiaryColor,
                                                          size: 50,
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          'Pending',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 10, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          '${_dashBoardModel.count.pending ?? ""}',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .bodyText1
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0, 15, 5, 0),
                                          child: InkWell(
                                            onTap: () async {
                                              await Navigator.push(
                                                context,
                                                MaterialPageRoute(
                                                  builder: (context) =>
                                                      ApprovedDetails(),
                                                ),
                                              ).then((value) =>
                                                  getDashBoardData());
                                            },
                                            child: Card(
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              color: Color(0xE8C5E4CE),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons.approval,
                                                        color: FlutterFlowTheme
                                                            .tertiaryColor,
                                                        size: 50,
                                                      )
                                                    ],
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          'Approved',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontWeight:
                                                                FontWeight.w800,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          '${_dashBoardModel.count.approved ?? ""}',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .bodyText1
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight.w800,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  5, 5, 0, 0),
                                          child: InkWell(
                                            /*   onTap: () async {
                                            await Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    DeletedUserWidget(),
                                              ),
                                            );
                                          }, */
                                            onTap: () async {
                                              await Navigator.push(
                                                context,
                                                PageTransition(
                                                  type: PageTransitionType.fade,
                                                  duration:
                                                      Duration(milliseconds: 0),
                                                  reverseDuration:
                                                      Duration(milliseconds: 0),
                                                  child: DeniedDetails(),
                                                ),
                                              ).then((value) =>
                                                  getDashBoardData());
                                            },
                                            child: Card(
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              color: Color(0xE8EEB7A9),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons
                                                            .disabled_by_default_rounded,
                                                        color: FlutterFlowTheme
                                                            .tertiaryColor,
                                                        size: 50,
                                                      )
                                                    ],
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          'Denied',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          '${_dashBoardModel.count.delete ?? ""}',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .bodyText1
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight.w800,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  0, 5, 5, 0),
                                          child: InkWell(
                                            /*   onTap: () async {
                                                                await Navigator.push(
                                                                  context,
                                                                  MaterialPageRoute(
                                                                    builder: (context) =>
                                                                        RevisedUserWidget(),
                                                                  ),
                                                                );
                                                              }, */
                                            onTap: () async {
                                              await Navigator.push(
                                                context,
                                                PageTransition(
                                                  type: PageTransitionType.fade,
                                                  duration:
                                                      Duration(milliseconds: 0),
                                                  reverseDuration:
                                                      Duration(milliseconds: 0),
                                                  child: ResubmittedDetails(),
                                                ),
                                              );
                                            },
                                            child: Card(
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              color: Color(0xFFDDC198),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons.update,
                                                        color: FlutterFlowTheme
                                                            .tertiaryColor,
                                                        size: 50,
                                                      )
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0, 5, 0, 0),
                                                        child: Text(
                                                          'Resubmitted',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontWeight:
                                                                FontWeight.w800,
                                                          ),
                                                        ),
                                                      )
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0, 5, 0, 0),
                                                        child: Text(
                                                          '${_dashBoardModel.count.revised ?? ""}',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                          ),
                                                        ),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        InkWell(
                                          onTap: () async {
                                            await Navigator.push(
                                              context,
                                              PageTransition(
                                                type: PageTransitionType.fade,
                                                duration:
                                                    Duration(milliseconds: 0),
                                                reverseDuration:
                                                    Duration(milliseconds: 0),
                                                child: ForwardDetails(),
                                              ),
                                            ).then(
                                                (value) => getDashBoardData());
                                          },
                                          child: Padding(
                                            padding:
                                                EdgeInsetsDirectional.fromSTEB(
                                                    5, 5, 0, 0),
                                            child: Card(
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              color: Color(0xE8B8C8E4),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons.forward,
                                                        color: FlutterFlowTheme
                                                            .tertiaryColor,
                                                        size: 50,
                                                      )
                                                    ],
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          'Forward',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding:
                                                        EdgeInsetsDirectional
                                                            .fromSTEB(
                                                                0, 5, 0, 0),
                                                    child: Row(
                                                      mainAxisSize:
                                                          MainAxisSize.max,
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          '${_dashBoardModel.count.forward ?? ""}',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .bodyText1
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontSize: 20,
                                                            fontWeight:
                                                                FontWeight.w500,
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                        Padding(
                                          padding:
                                              EdgeInsetsDirectional.fromSTEB(
                                                  5, 5, 5, 0),
                                          child: InkWell(
                                            onTap: () async {
                                              await Navigator.push(
                                                context,
                                                PageTransition(
                                                  type: PageTransitionType.fade,
                                                  duration:
                                                      Duration(milliseconds: 0),
                                                  reverseDuration:
                                                      Duration(milliseconds: 0),
                                                  child: AdminReportsWidget(),
                                                ),
                                              ).then((value) =>
                                                  getDashBoardData());
                                            },
                                            child: Card(
                                              clipBehavior:
                                                  Clip.antiAliasWithSaveLayer,
                                              color: Color(0x69D197E1),
                                              child: Column(
                                                mainAxisSize: MainAxisSize.max,
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Icon(
                                                        Icons
                                                            .analytics_outlined,
                                                        color: FlutterFlowTheme
                                                            .tertiaryColor,
                                                        size: 50,
                                                      )
                                                    ],
                                                  ),
                                                  Row(
                                                    mainAxisSize:
                                                        MainAxisSize.max,
                                                    mainAxisAlignment:
                                                        MainAxisAlignment
                                                            .center,
                                                    children: [
                                                      Padding(
                                                        padding:
                                                            EdgeInsetsDirectional
                                                                .fromSTEB(
                                                                    0, 5, 0, 0),
                                                        child: Text(
                                                          'Reports',
                                                          style:
                                                              FlutterFlowTheme
                                                                  .title3
                                                                  .override(
                                                            fontFamily:
                                                                'Roboto',
                                                            color: FlutterFlowTheme
                                                                .tertiaryColor,
                                                            fontWeight:
                                                                FontWeight.bold,
                                                          ),
                                                        ),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                          ),
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );

    // return Scaffold(
    //   appBar: AppBar(
    //    backgroundColor: Color(0xFFECA585),
    // centerTitle: true,
    // title: Text(
    //   _loading ? 'Loading...' : 'DAAPP',
    //   textAlign: TextAlign.center,
    //   style: TextStyle(color: Colors.white),
    //  ),
    //  actions: [
    //   IconButton(
    //     onPressed: () async {
    //       await UserDetails().logoutUser();
    //       Navigator.pushAndRemoveUntil(context,
    //          MaterialPageRoute(builder: (cont) {
    //        return LoginWidget();
    //      }), (route) => false);
    //  },
    //icon: Icon(Icons.logout))
    //],
    //),
    //   backgroundColor: Color(0xFFEBA889),
    // body: Container(
    // color: Colors.white,
    //height: double.infinity,
    //padding: const EdgeInsets.all(10),
    // child: GridView.builder(
    //     // itemCount: 20,
    //     gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(
    //         crossAxisCount:
    //             (orientation == Orientation.portrait) ? 2 : 2),
    //     itemCount: null == _users ? 0 : _users.length,
    //     itemBuilder: (context, index) {
    //       User user = _users[index];
    //       return new GestureDetector(
    //         child: new Card(
    //           color: RandomColorModel().getColor(),
    //           elevation: 0.0,
    //           shape: const RoundedRectangleBorder(
    //               borderRadius: BorderRadius.only(
    //             topLeft: Radius.circular(20.0),
    //             bottomLeft: Radius.circular(20.0),
    //             topRight: Radius.circular(20.0),
    //             bottomRight: Radius.circular(20.0),
    //           )),
    //           child: ListTile(
    //             leading: Icon(Icons.analytics_rounded, size: 45),
    //             title: Text(user.requeststatus),
    //             subtitle: Text(user.count),
    //           ),
    //           /* child: GridTile(
    //               footer: Text(user.count,
    //                   textAlign: TextAlign.center,
    //                   style: TextStyle(
    //                       color: Colors.grey[800],
    //                       fontWeight: FontWeight.bold,
    //                       fontSize: 50)),
    //               //new chil:Tex,
    //               child: Text(user.requeststatus.toUpperCase(),
    //                   textAlign: TextAlign.center,
    //                   style: TextStyle(
    //                       color: Colors.grey[800],
    //                       fontFamily: 'helvetica_neue_medium',
    //                       fontWeight: FontWeight.bold,
    //                       fontSize: 30)),
    //
    //               /* onTap: () {
    //           Navigator.push(context,
    //               MaterialPageRoute(builder: (_) => adminDash()));
    //         },  */
    //             ) */
    //         ),
    //         onTap: () {
    //           switch (user.requeststatus.toLowerCase()) {
    //             case "denied":
    //               {
    //                 Navigator.push(
    //                     context,
    //                     MaterialPageRoute(
    //                         builder: (_) => DeniedDetails()));
    //               }
    //               break;
    //             case "approved":
    //               {
    //                 Navigator.push(
    //                     context,
    //                     MaterialPageRoute(
    //                         builder: (_) => ApprovedDetails()));
    //               }
    //               break;
    //             case "revised":
    //               {
    //                 Navigator.push(
    //                     context,
    //                     MaterialPageRoute(
    //                         builder: (_) => RevisedDetails()));
    //               }
    //               break;
    //             case "pending":
    //               {
    //                 Navigator.push(
    //                     context,
    //                     MaterialPageRoute(
    //                         builder: (_) => PendingDetails()));
    //               }
    //               break;
    //             case "approved":
    //               {
    //                 Navigator.push(context,
    //                     MaterialPageRoute(builder: (_) => adminDash()));
    //               }
    //               break;
    //             case "forward":
    //               {
    //                 Navigator.push(
    //                     context,
    //                     MaterialPageRoute(
    //                         builder: (_) => ForwardDetails()));
    //               }
    //               break;
    //             default:
    //               break;
    //           }
    //           /*  showDialog(
    //       builder: (context) => new CupertinoAlertDialog(
    //         title: new Column(
    //           children: <Widget>[
    //             new Text("GridView"),
    //             new Icon(
    //               Icons.favorite,
    //               color: Colors.green,
    //             ),
    //           ],
    //         ),
    //         content: new Text("Selected Item $index"),
    //         actions: <Widget>[
    //           new FlatButton(
    //               onPressed: () {
    //                 Navigator.of(context).pop();
    //               },
    //               child: new Text("OK"))
    //         ],
    //       ),
    //       barrierDismissible: false,
    //       context: context,
    //     ); */
    //         },
    //       );
    //     }),
    /* child: SingleChildScrollView(
            child: Column(
              children: [
                SizedBox(height: 10),
                Text("Total Request ${totalRequestCount()}"),
                GridView(
                  padding: EdgeInsets.zero,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 4,
                    mainAxisSpacing: 10,
                    childAspectRatio: 1,
                  ),
                  scrollDirection: Axis.vertical,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                      child: InkWell(
                        onTap: () async {
                          // await Navigator.push(
                          //   context,
                          //   MaterialPageRoute(
                          //     builder: (context) =>
                          //         PendingUserWidget(),
                          //   ),
                          // );
                          await Navigator.push(
                            context,
                            PageTransition(
                              type: PageTransitionType.fade,
                              duration: Duration(milliseconds: 0),
                              reverseDuration: Duration(milliseconds: 0),
                              child: PendingDetails(),
                            ),
                          ).then((value) => getDashBoardData());
                        },
                        child: Card(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          color: Color(0xE8E9A6DE),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            children: [
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.pending_actions,
                                      color: FlutterFlowTheme.tertiaryColor,
                                      size: 50,
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Pending',
                                      style: FlutterFlowTheme.title3.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      '${_dashBoardModel.count.pending ?? ""}',
                                      style:
                                          FlutterFlowTheme.bodyText1.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 15, 5, 0),
                      child: InkWell(
                        onTap: () async {
                          await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => ApprovedDetails(),
                            ),
                          ).then((value) => getDashBoardData());
                        },
                        child: Card(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          color: Color(0xE8C5E4CE),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.approval,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Approved',
                                      style: FlutterFlowTheme.title3.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      '${_dashBoardModel.count.approved ?? ""}',
                                      style:
                                          FlutterFlowTheme.bodyText1.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                      child: InkWell(
                        /*   onTap: () async {
                                            await Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) =>
                                                    DeletedUserWidget(),
                                              ),
                                            );
                                          }, */
                        onTap: () async {
                          await Navigator.push(
                            context,
                            PageTransition(
                              type: PageTransitionType.fade,
                              duration: Duration(milliseconds: 0),
                              reverseDuration: Duration(milliseconds: 0),
                              child: DeniedDetails(),
                            ),
                          ).then((value) => getDashBoardData());
                        },
                        child: Card(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          color: Color(0xE8EEB7A9),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.delete,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Denied',
                                      style: FlutterFlowTheme.title3.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      '${_dashBoardModel.count.delete ?? ""}',
                                      style:
                                          FlutterFlowTheme.bodyText1.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w800,
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ), */
    // Padding(
    //   padding: EdgeInsetsDirectional.fromSTEB(
    //       0, 5, 5, 0),
    //   child: InkWell(
    //     /*   onTap: () async {
    //                         await Navigator.push(
    //                           context,
    //                           MaterialPageRoute(
    //                             builder: (context) =>
    //                                 RevisedUserWidget(),
    //                           ),
    //                         );
    //                       }, */
    //     onTap: () async {
    //       await Navigator.push(
    //         context,
    //         PageTransition(
    //           type: PageTransitionType.fade,
    //           duration: Duration(milliseconds: 0),
    //           reverseDuration:
    //           Duration(milliseconds: 0),
    //           child: RevisedDetails(),
    //         ),
    //       );
    //     },
    //     child: Card(
    //       clipBehavior: Clip.antiAliasWithSaveLayer,
    //       color: Color(0xFFDDC198),
    //       child: Column(
    //         mainAxisSize: MainAxisSize.max,
    //         mainAxisAlignment:
    //         MainAxisAlignment.center,
    //         children: [
    //           Row(
    //             mainAxisSize: MainAxisSize.max,
    //             mainAxisAlignment:
    //             MainAxisAlignment.center,
    //             children: [
    //               Icon(
    //                 Icons.update,
    //                 color: FlutterFlowTheme
    //                     .tertiaryColor,
    //                 size: 50,
    //               )
    //             ],
    //           ),
    //           Row(
    //             mainAxisSize: MainAxisSize.max,
    //             mainAxisAlignment:
    //             MainAxisAlignment.center,
    //             children: [
    //               Padding(
    //                 padding: EdgeInsetsDirectional
    //                     .fromSTEB(0, 5, 0, 0),
    //                 child: Text(
    //                   'Revised',
    //                   style: FlutterFlowTheme.title3
    //                       .override(
    //                     fontFamily: 'Roboto',
    //                     color: FlutterFlowTheme
    //                         .tertiaryColor,
    //                     fontWeight: FontWeight.w800,
    //                   ),
    //                 ),
    //               )
    //             ],
    //           ),
    //           Row(
    //             mainAxisSize: MainAxisSize.max,
    //             mainAxisAlignment:
    //             MainAxisAlignment.center,
    //             children: [
    //               Padding(
    //                 padding: EdgeInsetsDirectional
    //                     .fromSTEB(0, 5, 0, 0),
    //                 child: Text(
    //                   '${_dashBoardModel.count
    //                       .revised ?? ""}',
    //                   style: FlutterFlowTheme.title3
    //                       .override(
    //                     fontFamily: 'Roboto',
    //                     color: FlutterFlowTheme
    //                         .tertiaryColor,
    //                   ),
    //                 ),
    //               )
    //             ],
    //           )
    //         ],
    //       ),
    //     ),
    //   ),
    // ),
    /*          InkWell(
                      onTap: () async {
                        await Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.fade,
                            duration: Duration(milliseconds: 0),
                            reverseDuration: Duration(milliseconds: 0),
                            child: ForwardDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                        child: Card(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          color: Color(0xE8B8C8E4),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.forward,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Forward',
                                      style: FlutterFlowTheme.title3.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                      ),
                                    )
                                  ],
                                ),
                              ),
                              Padding(
                                padding:
                                    EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                                child: Row(
                                  mainAxisSize: MainAxisSize.max,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      '${_dashBoardModel.count.forward ?? ""}',
                                      style:
                                          FlutterFlowTheme.bodyText1.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                        fontSize: 20,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    )
                                  ],
                                ),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(5, 5, 5, 0),
                      child: InkWell(
                        onTap: () async {
                          await Navigator.push(
                            context,
                            PageTransition(
                              type: PageTransitionType.fade,
                              duration: Duration(milliseconds: 0),
                              reverseDuration: Duration(milliseconds: 0),
                              child: AdminReportsWidget(),
                            ),
                          ).then((value) => getDashBoardData());
                        },
                        child: Card(
                          clipBehavior: Clip.antiAliasWithSaveLayer,
                          color: Color(0x69D197E1),
                          child: Column(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.analytics_outlined,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                              Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding: EdgeInsetsDirectional.fromSTEB(
                                        0, 5, 0, 0),
                                    child: Text(
                                      'Reports',
                                      style: FlutterFlowTheme.title3.override(
                                        fontFamily: 'Roboto',
                                        color: FlutterFlowTheme.tertiaryColor,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  )
                                ],
                              )
                            ],
                          ),
                        ),
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        )); */
  }

  String totalRequestCount() {
    int total = 0;
    if (_dashBoardModel != null) {
      try {
        total = total + int.parse(_dashBoardModel.count.pending);
      } catch (e) {}

      try {
        total = total + int.parse(_dashBoardModel.count.approved);
      } catch (e) {}

      try {
        total = total + int.parse(_dashBoardModel.count.delete);
      } catch (e) {}
      try {
        total = total + int.parse(_dashBoardModel.count.revised);
      } catch (e) {}
      try {
        total = total + int.parse(_dashBoardModel.count.forward);
      } catch (e) {}
    }

    return total.toString();
  }

  void removeFocus() {
    FocusManager.instance.primaryFocus.unfocus();
  }
}
/* body: GridView.builder(
  itemCount: data.length,
  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
      crossAxisCount: (orientation == Orientation.portrait) ? 2 : 3),
  itemBuilder: (BuildContext context, int index) {
    return new Card(
      child: new GridTile(
        footer: new Text(data[index]['name']),
        child: new Text(data[index]
            ['image']), //just for testing, will fill with image later
      ),
    );
  },
), */
