class Constants {
  static const String Profile = 'Back';
  //static const String Settings = 'Settings';
  static const String Logout = 'Logout';

  static const List<String> choices = <String>[Profile, Logout];
}
