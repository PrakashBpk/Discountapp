import 'dart:convert';

List<UserModel> userModelFromJson(String str) =>
    List<UserModel>.from(json.decode(str).map((x) => UserModel.fromJson(x)));

String userModelToJson(List<UserModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class UserModel {
  UserModel({
    this.userId,
    this.userName,
    this.userPassword,
    this.userRole,
  });

  String userId;
  String userName;
  String userPassword;
  String userRole;

  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        userId: json["user_id"] ?? json["id"],
        userName: json["user_name"] ?? json["name"],
        userPassword: json["user_password"] ?? json["email"],
        userRole: json["user_role"] ?? json["role"],
      );

  Map<String, dynamic> toJson() => {
        "user_id": userId,
        "user_name": userName,
        "user_password": userPassword,
        "user_role": userRole,
      };
}
