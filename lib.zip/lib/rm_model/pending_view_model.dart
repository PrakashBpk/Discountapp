import 'dart:convert';

List<PendingViewModel> pendingViewModelFromJson(String str) =>
    List<PendingViewModel>.from(
        json.decode(str).map((x) => PendingViewModel.fromJson(x)));

String pendingViewModelToJson(List<PendingViewModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class PendingViewModel {
  PendingViewModel(
      {this.requestId,
      this.bookId,
      this.custName,
      this.userName,
      this.offerName,
      this.branch,
      this.carModel,
      this.carColor,
      this.yearMake,
      this.discount,
      this.status,
      this.userId,
      this.approvedby,
      this.approvedin,
      this.requestDate,
      this.reviseddiscount,
      this.updateddate,
      this.deniedrequest,
      this.sum,
      this.slatime});

  String requestId;
  String bookId;
  String custName;
  String carModel;
  String offerName;
  String carColor;
  String branch;
  String slatime;
  String userName;
  String yearMake;
  String discount;
  String status;
  String deniedrequest;
  String userId;
  String reviseddiscount;
  String approvedby;
  String approvedin;
  String sum;
  String updateddate;
  DateTime requestDate;

  factory PendingViewModel.fromJson(Map<String, dynamic> json) =>
      PendingViewModel(
        requestId: json["request_id"],
        bookId: json["book_id"],
        custName: json["cust_name"],
        carModel: json["car_model"],
        userName: json["user_name"],
        branch: json["branch"],
        offerName: json["offer_name"],
        carColor: json["car_color"],
        yearMake: json["year_make"],
        approvedby: json["Approved_by"],
        reviseddiscount: json["reviseddiscount"],
        approvedin: json["approved_in"],
        discount: json["discount"] ?? "",
        status: json["status"] ?? "",
        sum: json["Sum"],
        deniedrequest: json["deniedrequest"] ?? "",
        userId: json["user_id"] ?? "",
        slatime: json["slatime"] ?? "",
        updateddate: json["updated_date"] ?? "",
        requestDate: json["request_date"] == null
            ? null
            : DateTime.parse(json["request_date"]),
      );

  Map<String, dynamic> toJson() => {
        "book_id": bookId,
        "cust_name": custName,
        "car_model": carModel,
        "car_color": carColor,
        "user_name": userName,
        "branch": branch,
        "offer_name": offerName,
        "year_make": yearMake,
        "discount": discount,
        "status": status,
        "reviseddiscount": reviseddiscount,
        "user_id": userId,
        "slatime": slatime,
        "sum": sum,
        "deniedrequest": deniedrequest,
        "approved_in": approvedin,
        "Approved_by": approvedby,
        "updated_date": updateddate,
        "request_date": requestDate.toIso8601String(),
      };
}
