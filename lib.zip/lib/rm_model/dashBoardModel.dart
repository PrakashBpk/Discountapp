import 'dart:convert';

DashBoardModel dashBoardModelFromJson(String str) =>
    DashBoardModel.fromJson(json.decode(str));

String dashBoardModelToJson(DashBoardModel data) => json.encode(data.toJson());

class DashBoardModel {
  DashBoardModel({
    this.count,
    this.response,
  }) {
    if (count == null) {
      count = Count();
    }
  }

  Count count;
  String response;

  factory DashBoardModel.fromJson(Map<String, dynamic> json) => DashBoardModel(
        count: json["count"] != null ? Count.fromJson(json["count"]) : Count(),
        response: json["response"],
      );

  Map<String, dynamic> toJson() => {
        "count": count.toJson(),
        "response": response,
      };
}

class Count {
  Count({
    this.pending = "0",
    this.approved = "0",
    this.revised = "0",
    this.forward = "0",
    this.delete = "0",
    this.openrquest = "0",
    this.openrquestin = "0",
    this.openrquestout = "0",
    this.closedrequestin = "0",
    this.closedrequestout = "0",
    this.closedrequest = "0",
    this.totalrequest = "0",
    this.pendingintime = "0",
    this.pendingouttime = "0",
    this.approvedintime = "0",
    this.forwardin = "0",
    this.forwardout = "0",
    this.revisedin = "0",
    this.revisedout = "0",
    this.deniedin = "0",
    this.deniedout = "0",
    this.bmforwardin = "0",
    this.bmforwardout = "0",
    this.bmresubmittedforwardin = "0",
    this.bmresubmittedforwardout = "0",
    this.approvedouttime = "0",
    this.withlimit = "0",
    this.abovelimit = "0",
    this.sum,
  });

  String pending;
  String approved;
  String revised;
  String forward;
  String delete;
  String withlimit;
  String forwardin;
  String forwardout;
  String revisedin;
  String revisedout;
  String totalrequest;
  String pendingintime;
  String pendingouttime;
  String approvedintime;
  String approvedouttime;
  String deniedin;
  String deniedout;
  String bmforwardin;
  String bmforwardout;
  String bmresubmittedforwardout;
  String bmresubmittedforwardin;
  String openrquest;
  String openrquestin;
  String openrquestout;
  String closedrequest;
  String closedrequestin;
  String closedrequestout;
  String abovelimit;
  String sum;

  factory Count.fromJson(Map<String, dynamic> json) => Count(
        pending: json["pending"] ?? "0",
        approved: json["approved"] ?? "0",
        revised: json["revised"] ?? "0",
        withlimit: json["withlimit"] ?? "0",
        abovelimit: json["abovelimit"] ?? "0",
        forward: json["forward"] ?? "0",
        openrquest: json["openrequest"] ?? "0",
        openrquestin: json["openrequestin"] ?? "0",
        openrquestout: json["openrequestout"] ?? "0",
        forwardin: json["forwardin"] ?? "0",
        forwardout: json["forwardout"] ?? "0",
        revisedin: json["revisedin"] ?? "0",
        revisedout: json["revisedout"] ?? "0",
        closedrequest: json["closedrequest"] ?? "0",
        closedrequestin: json["closedrequestin"] ?? "0",
        closedrequestout: json["closedrequestout"] ?? "0",
        sum: json["Sum"] ?? "0",
        totalrequest: json["totalrequest"] ?? "0",
        pendingintime: json["pendingintime"] ?? "0",
        pendingouttime: json["pendingouttime"] ?? "0",
        approvedintime: json["approvedintime"] ?? "0",
        approvedouttime: json["approvedouttime"] ?? "0",
        deniedin: json["deniedin"] ?? "0",
        deniedout: json["deniedout"] ?? "0",
        bmforwardin: json["bmforwardin"] ?? "0",
        bmforwardout: json["mforwardout"] ?? "0",
        bmresubmittedforwardin: json["bmresubmittedforwardin"] ?? "0",
        bmresubmittedforwardout: json["bmresubmittedforwardout"] ?? "0",
        delete: json["delete"] ?? json["denied"] ?? "0",
      );

  Map<String, dynamic> toJson() => {
        "pending": pending,
        "approved": approved,
        "revised": revised,
        "forward": forward,
        "forwardin": forwardin,
        "forwardout": forwardout,
        "revisedin": revisedin,
        "revisedout": revisedout,
        "delete": delete,
        'abovelimit': abovelimit,
        'withlimit': withlimit,
        'totalrequest': totalrequest,
        'pendingintime': pendingintime,
        'pendingouttime': pendingouttime,
        'openrequest': openrquest,
        'closedrequest': closedrequest,
        'approvedintime': approvedintime,
        'Sum': sum,
        'approvedouttime': approvedouttime
      };
}
