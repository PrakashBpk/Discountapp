import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_model/pending_view_model.dart';
import 'package:RM_DAAPP/rm_other/common.dart';
import 'package:RM_DAAPP/rm_revise/revise_widget.dart';
import 'package:RM_DAAPP/rm_approved_details/approved_details_widget.dart';
import 'package:RM_DAAPP/rm_widget/user_data_widget.dart';

import '../RM_flutter_flow/flutter_flow_icon_button.dart';
import '../RM_flutter_flow/flutter_flow_theme.dart';
import '../RM_flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_session/flutter_session.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/smtp_server.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:email_auth/email_auth.dart';
import 'package:http/http.dart' as http;

class ForwardUserWidget extends StatefulWidget {
  const ForwardUserWidget({Key key}) : super(key: key);

  @override
  _ForwardUserWidgetState createState() => _ForwardUserWidgetState();
}

class _ForwardUserWidgetState extends State<ForwardUserWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  Future<List<PendingViewModel>> getForwardData(String userId) async {
    List<PendingViewModel> pendingList = [];
    try {
      var url =
          "http://118.91.235.247/daapp/api/forward_view.php?user_id=$userId";
      var response = await http.get(url);
      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.red,
        automaticallyImplyLeading: true,
        title: Text(
          'Forwarded',
          style: FlutterFlowTheme.bodyText1.override(
            fontFamily: 'Roboto',
            color: Color(0xFFF5EDED),
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 4,
      ),
      backgroundColor: FlutterFlowTheme.tertiaryColor,
      body: SafeArea(
        child: Container(
          width: MediaQuery.of(context).size.width * 7,
          height: 1000,
          decoration: BoxDecoration(
            color: Color(0xFFEEEEEE),
          ),
          child: FutureBuilder(
            future: getForwardData(userData.userId),
            builder: (context, AsyncSnapshot<List<PendingViewModel>> snapshot) {
              if (snapshot.connectionState != ConnectionState.done) {
                return Container(
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                );
              }
              if (snapshot.data == null || snapshot.data.isEmpty) {
                return Container(
                  child: Center(
                    child: Text(
                      "Record not found...",
                      style: TextStyle(
                          color: Colors.grey,
                          fontSize: 16,
                          fontWeight: FontWeight.w600),
                    ),
                  ),
                );
              }

              return ListView.builder(
                  itemCount: snapshot.data.length,
                  shrinkWrap: true,
                  // physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) {
                    PendingViewModel pendingViewModel = snapshot.data[index];
                    return InkWell(
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ApprovedDetailsWidget(
                              pendingViewModel: pendingViewModel,
                            ),
                          ),
                        );
                      },
                      child: UserDataWidget(
                        pendingViewModel: pendingViewModel,
                      ),
                    );
                  });
            },
          ),
        ),
      ),
    );
  }
}
