import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/admin_dash.dart';
import 'package:RM_DAAPP/approved_details/admin_approved_details_widget.dart';
import 'package:RM_DAAPP/editdata.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/widget/user_data_widget.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'JsonParseDemo.dart';
import 'Users.dart';
import 'approved_details/approved_details_widget.dart';
import 'details.dart';
import 'flutter_flow/flutter_flow_theme.dart';
import 'flutter_flow/flutter_flow_widgets.dart';
import 'model/pending_view_model.dart';
import 'newdata.dart';

class PendingDetails extends StatefulWidget {
  @override
  _PendingDetailsState createState() => _PendingDetailsState();
}

class _PendingDetailsState extends State<PendingDetails> {
  Future<List<PendingViewModel>> getPendingData(String userId) async {
    List<PendingViewModel> pendingList = [];
    try {
      var response = await http.get(
          "http://118.91.235.247/daapp/api/admin_pending_view.php?admin_id=${userData.userId}");
      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Pending Lists"),
        backgroundColor: Colors.red,
      ),
      body: FutureBuilder(
        future: getPendingData(userData.userId),
        builder: (cont, AsyncSnapshot<List<PendingViewModel>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return Container(
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.data == null || snapshot.data.isEmpty) {
            return Container(
              child: Center(
                child: Text(
                  "Record not found...",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
            );
          }

          return ListView.builder(
              itemCount: snapshot.data.length,
              shrinkWrap: true,
              // physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                PendingViewModel pendingViewModel = snapshot.data[index];
                return InkWell(
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AdminApprovedDetailsWidget(
                          pendingViewModel: pendingViewModel,
                        ),
                      ),
                    ).then((value) {
                      setState(() {});
                    });
                  },
                  child: UserDataWidget(
                    pendingViewModel: pendingViewModel,
                    // onDelete: () {
                    // deletePendingData(
                    //     userData.userId, pendingViewModel.bookId);
                    // },
                  ),
                );
              });
        },
      ),
    );
  }
}
