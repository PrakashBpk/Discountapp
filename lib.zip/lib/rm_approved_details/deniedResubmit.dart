import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_model/pending_view_model.dart';
import 'package:RM_DAAPP/rm_other/common.dart';
import 'package:RM_DAAPP/rm_revise/revise_widget.dart';
import 'package:RM_DAAPP/rm_revise/userRevised.dart';

import '../RM_flutter_flow/flutter_flow_icon_button.dart';
import '../RM_flutter_flow/flutter_flow_theme.dart';
import '../RM_flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_session/flutter_session.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/smtp_server.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:email_auth/email_auth.dart';

class DeniedDetailsWidget extends StatefulWidget {
  PendingViewModel pendingViewModel;

  DeniedDetailsWidget({
    this.pendingViewModel,
  });

  @override
  _DeniedDetailsWidgetState createState() => _DeniedDetailsWidgetState();
}

class _DeniedDetailsWidgetState extends State<DeniedDetailsWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.red,
        automaticallyImplyLeading: false,
        leading: FlutterFlowIconButton(
          borderColor: Colors.transparent,
          borderRadius: 30,
          buttonSize: 46,
          icon: Icon(
            Icons.arrow_back_rounded,
            color: Color(0xFFF5EDED),
            size: 24,
          ),
          onPressed: () async {
            Navigator.pop(context);
          },
        ),
        title: Text(
          'Information',
          style: FlutterFlowTheme.title1.override(
            fontFamily: 'Roboto',
            color: Color(0xFFF5EDED),
            fontWeight: FontWeight.w600,
          ),
        ),
        actions: [],
        centerTitle: false,
        elevation: 0,
      ),
      backgroundColor: FlutterFlowTheme.tertiaryColor,
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Padding(
              padding: EdgeInsetsDirectional.fromSTEB(1, 0, 0, 0),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(0, 12, 0, 0),
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.96,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              blurRadius: 4,
                              color: Color(0x3A000000),
                              offset: Offset(0, 2),
                            )
                          ],
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  16, 16, 16, 12),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    '${widget.pendingViewModel.bookId ?? ""}',
                                    style: FlutterFlowTheme.subtitle2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF090F13),
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.requestDate}',
                                      textAlign: TextAlign.end,
                                      style: FlutterFlowTheme.bodyText1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Sales_Executive_Name',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.userName ?? ""}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Customer Name',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.custName}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // Padding(
                            //   padding:
                            //       EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                            //   child: Row(
                            //     mainAxisSize: MainAxisSize.max,
                            //     mainAxisAlignment:
                            //         MainAxisAlignment.spaceBetween,
                            //     children: [
                            //       Text(
                            //         ' Sales Executive',
                            //         style: FlutterFlowTheme.bodyText2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF8B97A2),
                            //           fontSize: 14,
                            //           fontWeight: FontWeight.normal,
                            //         ),
                            //       ),
                            //       Text(
                            //         'Praveen',
                            //         textAlign: TextAlign.end,
                            //         style: FlutterFlowTheme.subtitle2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF111417),
                            //           fontSize: 16,
                            //           fontWeight: FontWeight.bold,
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                            // Padding(
                            //   padding:
                            //       EdgeInsetsDirectional.fromSTEB(16, 0, 16, 12),
                            //   child: Row(
                            //     mainAxisSize: MainAxisSize.max,
                            //     mainAxisAlignment:
                            //         MainAxisAlignment.spaceBetween,
                            //     children: [
                            //       Text(
                            //         'Branch',
                            //         style: FlutterFlowTheme.bodyText2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF8B97A2),
                            //           fontSize: 14,
                            //           fontWeight: FontWeight.normal,
                            //         ),
                            //       ),
                            //       Text(
                            //         'Coimbatore',
                            //         textAlign: TextAlign.end,
                            //         style: FlutterFlowTheme.subtitle2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF111417),
                            //           fontSize: 16,
                            //           fontWeight: FontWeight.bold,
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Car Model',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.carModel ?? ""}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Year Make',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.yearMake ?? ""}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Car color',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.carColor ?? ""}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Branch',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.branch ?? ""}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Current_Offer',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Expanded(
                                    child: Text(
                                      '${widget.pendingViewModel.offerName ?? ""}',
                                      textAlign: TextAlign.end,
                                      style:
                                          FlutterFlowTheme.subtitle2.override(
                                        fontFamily: 'Roboto',
                                        color: Color(0xFF111417),
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            // Padding(
                            //   padding:
                            //       EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                            //   child: Row(
                            //     mainAxisSize: MainAxisSize.max,
                            //     mainAxisAlignment:
                            //         MainAxisAlignment.spaceBetween,
                            //     children: [
                            //       Text(
                            //         'Current Offer',
                            //         style: FlutterFlowTheme.bodyText2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF8B97A2),
                            //           fontSize: 14,
                            //           fontWeight: FontWeight.normal,
                            //         ),
                            //       ),
                            //       Expanded(
                            //         child: Text(
                            //           'New Year',
                            //           textAlign: TextAlign.end,
                            //           style: FlutterFlowTheme.subtitle2.override(
                            //             fontFamily: 'Roboto',
                            //             color: Color(0xFF111417),
                            //             fontSize: 16,
                            //             fontWeight: FontWeight.bold,
                            //           ),
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    'Discount Value',
                                    style: FlutterFlowTheme.bodyText2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF8B97A2),
                                      fontSize: 14,
                                      fontWeight: FontWeight.normal,
                                    ),
                                  ),
                                  Text(
                                    '${widget.pendingViewModel.discount ?? ""}',
                                    textAlign: TextAlign.end,
                                    style: FlutterFlowTheme.subtitle2.override(
                                      fontFamily: 'Roboto',
                                      color: Color(0xFF111417),
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            // Padding(
                            //   padding:
                            //       EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                            //   child: Row(
                            //     mainAxisSize: MainAxisSize.max,
                            //     mainAxisAlignment:
                            //         MainAxisAlignment.spaceBetween,
                            //     children: [
                            //       Text(
                            //         'Existing Customer',
                            //         style: FlutterFlowTheme.bodyText2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF8B97A2),
                            //           fontSize: 14,
                            //           fontWeight: FontWeight.normal,
                            //         ),
                            //       ),
                            //       Text(
                            //         'No',
                            //         textAlign: TextAlign.end,
                            //         style: FlutterFlowTheme.subtitle2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF111417),
                            //           fontSize: 16,
                            //           fontWeight: FontWeight.bold,
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                            // Padding(
                            //   padding:
                            //       EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                            //   child: Row(
                            //     mainAxisSize: MainAxisSize.max,
                            //     mainAxisAlignment:
                            //         MainAxisAlignment.spaceBetween,
                            //     children: [
                            //       Text(
                            //         'Referred Customer',
                            //         style: FlutterFlowTheme.bodyText2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF8B97A2),
                            //           fontSize: 14,
                            //           fontWeight: FontWeight.normal,
                            //         ),
                            //       ),
                            //       Text(
                            //         'Yes',
                            //         textAlign: TextAlign.end,
                            //         style: FlutterFlowTheme.subtitle2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF111417),
                            //           fontSize: 16,
                            //           fontWeight: FontWeight.bold,
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                            // Padding(
                            //   padding:
                            //       EdgeInsetsDirectional.fromSTEB(16, 0, 16, 8),
                            //   child: Row(
                            //     mainAxisSize: MainAxisSize.max,
                            //     mainAxisAlignment:
                            //         MainAxisAlignment.spaceBetween,
                            //     children: [
                            //       Text(
                            //         'Referrer Name',
                            //         style: FlutterFlowTheme.bodyText2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF8B97A2),
                            //           fontSize: 14,
                            //           fontWeight: FontWeight.normal,
                            //         ),
                            //       ),
                            //       Text(
                            //         'Rahul',
                            //         textAlign: TextAlign.end,
                            //         style: FlutterFlowTheme.subtitle2.override(
                            //           fontFamily: 'Roboto',
                            //           color: Color(0xFF111417),
                            //           fontSize: 16,
                            //           fontWeight: FontWeight.bold,
                            //         ),
                            //       ),
                            //     ],
                            //   ),
                            // ),
                          ],
                        ),
                      ),
                    ),
                    Divider(
                      height: 2,
                      thickness: 1,
                      indent: 16,
                      endIndent: 16,
                      color: Colors.transparent,
                    ),
                    Padding(
                      padding:
                          EdgeInsets.symmetric(vertical: 20, horizontal: 140),
                      child: Row(
                        children: [
                          _button(
                            title: "Resubmit",
                            color: Colors.orange,
                            onTap: () {
                              // revisedApi(
                              //     userId: widget.pendingViewModel.userId,
                              //     reqId: widget.pendingViewModel.requestId);
                              Navigator.push(context,
                                  MaterialPageRoute(builder: (cont) {
                                return userReviseWidget(
                                  pendingViewModel: widget.pendingViewModel,
                                );
                              }));
                            },
                          ),
                          /*   _button(
                      title: "Deny",
                      color: Colors.redAccent,
                      onTap: () {
                        deniedApi(
                            userId: widget.pendingViewModel.userId,
                            reqId: widget.pendingViewModel.requestId);
                      }),
                  _button(
                    title: "Revise",
                    color: Colors.orange,
                    onTap: () {
                      // revisedApi(
                      //     userId: widget.pendingViewModel.userId,
                      //     reqId: widget.pendingViewModel.requestId);
                      Navigator.push(context,
                          MaterialPageRoute(builder: (cont) {
                        return ReviseWidget(
                          pendingViewModel: widget.pendingViewModel,
                        );
                      }));
                    },
                  ),
                  _button(
                      title: "Forward",
                      color: Colors.lightBlueAccent,
                      onTap: () {
                        forwardApi(
                            userId: widget.pendingViewModel.userId,
                            reqId: widget.pendingViewModel.requestId);
                      }),
                  _button(
                      title: "Deny Permanent",
                      color: Colors.redAccent,
                      onTap: () {
                        deniedApi(
                            userId: widget.pendingViewModel.userId,
                            reqId: widget.pendingViewModel.requestId);
                      }), */
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _button({String title, Color color, Function onTap}) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: Container(
          alignment: Alignment.center,
          padding: EdgeInsets.symmetric(vertical: 8),
          margin: EdgeInsets.symmetric(horizontal: 2),
          child: Text(
            title ?? "",
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(5),
          ),
        ),
      ),
    );
  }
}
