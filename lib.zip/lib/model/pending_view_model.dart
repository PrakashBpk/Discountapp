import 'dart:convert';

List<PendingViewModel> pendingViewModelFromJson(String str) =>
    List<PendingViewModel>.from(
        json.decode(str).map((x) => PendingViewModel.fromJson(x)));

String pendingViewModelToJson(List<PendingViewModel> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class PendingViewModel {
  PendingViewModel({
    this.requestId,
    this.bookId,
    this.custName,
    this.userName,
    this.offerName,
    this.branch,
    this.carModel,
    this.carColor,
    this.yearMake,
    this.discount,
    this.status,
    this.userId,
    this.slatime,
    this.revisedDiscount,
    this.Approvedby,
    this.resubmittedDiscount,
    this.requestDate,
  });

  String requestId;
  String bookId;
  String custName;
  String carModel;
  String offerName;
  String carColor;
  String branch;
  String userName;
  String yearMake;
  String discount;
  String status;
  String userId;
  String slatime;
  String Approvedby;
  String revisedDiscount;
  String resubmittedDiscount;

  DateTime requestDate;

  factory PendingViewModel.fromJson(Map<String, dynamic> json) =>
      PendingViewModel(
        requestId: json["request_id"],
        Approvedby: json["Approved_by"],
        bookId: json["book_id"],
        custName: json["cust_name"],
        carModel: json["car_model"],
        userName: json["user_name"],
        branch: json["branch"],
        offerName: json["offers"],
        carColor: json["car_color"],
        yearMake: json["year_make"],
        discount: json["discount"] ?? "",
        status: json["status"] ?? "",
        revisedDiscount: json['revised_discount'] ?? "",
        resubmittedDiscount: json['resubmitted_discount'] ?? "",
        userId: json["user_id"] ?? "",
        slatime: json["slatime"] ?? "",
        requestDate: json["request_date"] == null
            ? null
            : DateTime.parse(json["request_date"]),
      );

  Map<String, dynamic> toJson() => {
        "book_id": bookId,
        "cust_name": custName,
        "car_model": carModel,
        "car_color": carColor,
        "Approved_by": Approvedby,
        "user_name": userName,
        "branch_name": branch,
        "offer_name": offerName,
        "year_make": yearMake,
        "discount": discount,
        "status": status,
        "user_id": userId,
        "slatime": slatime,
        "revised_discount": revisedDiscount,
        "resubmitted_discount": resubmittedDiscount,
        "request_date": requestDate.toIso8601String(),
      };
}
