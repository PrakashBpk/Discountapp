import 'package:flutter/material.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_theme.dart';
import 'package:RM_DAAPP/model/pending_view_model.dart';

class UserDataWidget extends StatelessWidget {
  PendingViewModel pendingViewModel;
  Function onDelete;
  Widget child;

  UserDataWidget({this.pendingViewModel, this.onDelete, this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      margin: EdgeInsets.symmetric(horizontal: 5, vertical: 5),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(5),
          boxShadow: [
            BoxShadow(
                color: Colors.grey.withOpacity(0.5),
                spreadRadius: 2,
                blurRadius: 2),
          ]),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Text(
                '${pendingViewModel.bookId ?? ""}',
                style: FlutterFlowTheme.bodyText1,
              ),
              Expanded(
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                  child: Text(
                    "${pendingViewModel.requestDate ?? ""}",
                    // '10-12-2021 13:56:40',
                    textAlign: TextAlign.end,
                    style: FlutterFlowTheme.bodyText1,
                  ),
                ),
              ),
            ],
          ),
          RichText(
            text: TextSpan(
              text: "",
              children: [
                WidgetSpan(
                    child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                  child: Text(
                    '${pendingViewModel.custName ?? ""}',
                    style: FlutterFlowTheme.bodyText1.override(
                      fontFamily: 'Roboto',
                    ),
                  ),
                )),
                WidgetSpan(
                    child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                  child: Text(
                    '${pendingViewModel.carModel ?? ""}',
                    style: FlutterFlowTheme.bodyText1.override(
                      fontFamily: 'Roboto',
                    ),
                  ),
                )),
                WidgetSpan(
                    child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                  child: Text(
                    '${pendingViewModel.yearMake ?? ""}',
                    style: FlutterFlowTheme.bodyText1.override(
                      fontFamily: 'Roboto',
                    ),
                  ),
                )),
                WidgetSpan(
                    child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(10, 5, 0, 0),
                  child: Text(
                    '${pendingViewModel.carColor ?? ""}',
                    style: FlutterFlowTheme.bodyText1.override(
                      fontFamily: 'Roboto',
                    ),
                  ),
                )),
              ],
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Expanded(
                child: Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                  child: Text(
                    '${pendingViewModel.discount ?? ""}',
                    style: FlutterFlowTheme.bodyText1.override(
                      fontFamily: 'Roboto',
                    ),
                  ),
                ),
              ),
              if (onDelete != null)
                IconButton(
                    onPressed: onDelete,
                    icon: Icon(
                      Icons.delete,
                      color: Colors.red,
                    ))
            ],
          ),
        ],
      ),
    );
  }
}
