import 'dart:async';

import 'package:RM_DAAPP/approved_details/deniedResubmit.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_icon_button.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_widgets.dart';
import 'package:RM_DAAPP/model/dashBoardModel.dart';
import 'package:RM_DAAPP/model/pending_view_model.dart';
import 'package:RM_DAAPP/model/user_model.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/other/userDetails.dart';
import 'package:RM_DAAPP/userpage.dart';
import 'package:RM_DAAPP/userpage.dart';
import 'package:RM_DAAPP/widget/user_data_widget.dart';

import '../approved_details/approved_details_widget.dart';
import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

class DeletedUserWidget extends StatefulWidget {
  const DeletedUserWidget({Key key}) : super(key: key);

  @override
  _DeletedUserWidgetState createState() => _DeletedUserWidgetState();
}

class _DeletedUserWidgetState extends State<DeletedUserWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  UserDetails userDetails = UserDetails();

  Timer timer;
  List<DashBoardModel> _users;
  bool _loading;
  Future<List<PendingViewModel>> getDeniedData() async {
    List<PendingViewModel> pendingList = [];
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var url =
          "http://118.91.235.247/daapp/api/denied_view.php?user_id=${userModel.userId}";
      var response = await http.get(url);

      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(
      Duration(seconds: 10),
      (Timer t) => getDeniedData().then((users) {
        setState(() {
          _users = users.cast<DashBoardModel>();
          print("object");
          _loading = false;
        });
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
        onWillPop: () async {
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('You should  only control inside app ')));
          return false;
        },
        child: Scaffold(
          key: scaffoldKey,
          appBar: AppBar(
            backgroundColor: Colors.red,
            automaticallyImplyLeading: false,
            leading: FlutterFlowIconButton(
              borderColor: Colors.transparent,
              borderRadius: 30,
              buttonSize: 46,
              icon: Icon(
                Icons.arrow_back_rounded,
                color: Color(0xFFF5EDED),
                size: 24,
              ),
              onPressed: () async {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => UserWidget()));
              },
            ),
            title: Text(
              'Denied List',
              style: FlutterFlowTheme.bodyText1.override(
                fontFamily: 'Roboto',
                color: Color(0xFFF5EDED),
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            actions: [],
            centerTitle: true,
            elevation: 4,
          ),
          backgroundColor: FlutterFlowTheme.tertiaryColor,
          body: SafeArea(
            child: Container(
              width: MediaQuery.of(context).size.width * 7,
              height: 1000,
              decoration: BoxDecoration(
                color: Color(0xFFEEEEEE),
              ),
              child: FutureBuilder(
                future: getDeniedData(),
                builder:
                    (context, AsyncSnapshot<List<PendingViewModel>> snapshot) {
                  if (snapshot.connectionState != ConnectionState.done) {
                    return Container(
                      child: Center(
                        child: Text("page reloading please wait "),
                        // child: CircularProgressIndicator(),
                      ),
                    );
                  }
                  if (snapshot.data == null || snapshot.data.isEmpty) {
                    return Container(
                      child: Center(
                        child: Text(
                          "Record not found...",
                          style: TextStyle(
                              color: Colors.grey,
                              fontSize: 16,
                              fontWeight: FontWeight.w600),
                        ),
                      ),
                    );
                  }

                  return ListView.builder(
                      itemCount: snapshot.data.length,
                      shrinkWrap: true,
                      // physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (context, index) {
                        PendingViewModel pendingViewModel =
                            snapshot.data[index];
                        return InkWell(
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DeniedDetailsWidget(
                                  pendingViewModel: pendingViewModel,
                                ),
                              ),
                            );
                          },
                          child: UserDataWidget(
                            pendingViewModel: pendingViewModel,
                          ),
                        );
                      });
                },
              ),
            ),
          ),
        ));
  }
}
