import 'dart:async';

import 'package:RM_DAAPP/bm_userlogin.dart';
import 'package:RM_DAAPP/bm_userpage.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_widgets.dart';
import 'package:RM_DAAPP/rm_Login.dart';
import 'package:RM_DAAPP/rm_userlogin.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/JsonParseDemo.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_theme.dart';
import 'package:RM_DAAPP/model/user_model.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/other/userDetails.dart';
import 'package:RM_DAAPP/userlogin.dart';
import 'package:RM_DAAPP/userpage.dart';

import 'Login.dart';

class loginchoicescreen extends StatefulWidget {
  @override
  _loginchoiceState createState() => _loginchoiceState();
}

class _loginchoiceState extends State<loginchoicescreen> {
  UserDetails userDetails = UserDetails();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FlutterFlowTheme.tertiaryColor,
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 1,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              blurRadius: 700,
              color: Color(0xE8E79D8C),
              spreadRadius: 10000,
            )
          ],
          gradient: LinearGradient(
            colors: [Colors.red, Color(0xE8E9A6DE), Colors.white],
            stops: [1, 1, 1],
            begin: AlignmentDirectional(1, 0.34),
            end: AlignmentDirectional(-1, -0.34),
          ),
        ),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(60, 0, 0, 0),
                    child: Text(
                      'Welcome to Daapp',
                      style: FlutterFlowTheme.title1.override(
                        fontFamily: 'Roboto',
                        color: FlutterFlowTheme.tertiaryColor,
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                //  mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(20, 80, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => srUserLoginWidget(),
                          ),
                        ).then((value) {
                          setState(() {});
                        });
                      },
                      text: 'SalesRep',
                      options: FFButtonOptions(
                        width: 230,
                        height: 50,
                        color: Color(0xFFFFFFFF),
                        textStyle: FlutterFlowTheme.subtitle2.override(
                          fontFamily: 'Roboto',
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        elevation: 8,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: 100,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                //  mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(60, 30, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => bmLoginWidget(),
                          ),
                        ).then((value) {
                          setState(() {});
                        });
                      },
                      text: 'BM',
                      options: FFButtonOptions(
                        width: 230,
                        height: 50,
                        color: Colors.white,
                        textStyle: FlutterFlowTheme.subtitle2.override(
                          fontFamily: 'Roboto',
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        elevation: 8,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: 100,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                //  mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(90, 30, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => rmLoginWidget(),
                          ),
                        ).then((value) {
                          setState(() {});
                        });
                      },
                      text: 'RM',
                      options: FFButtonOptions(
                        width: 230,
                        height: 50,
                        color: Colors.white,
                        textStyle: FlutterFlowTheme.subtitle2.override(
                          fontFamily: 'Roboto',
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        elevation: 8,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: 100,
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 150, 0, 0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Powered by Geekdino Labs',
                      style: FlutterFlowTheme.bodyText1.override(
                        fontFamily: 'Roboto',
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 18,
                        fontStyle: FontStyle.italic,
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
