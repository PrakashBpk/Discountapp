import 'dart:async';

import 'package:http/http.dart' as http;
import 'package:RM_DAAPP/Users.dart';

/* main() {
  const oneSec = Duration(seconds: 1);
  Timer.periodic(oneSec, (Timer t) => print('hi!'));
} */

class Services {
  //
  static const String url = 'http://118.91.235.247/daapp/api/pendingcount.php';
  static Future<List<User>> getUsers() async {
    try {
      final response = await http.get(url);
      if (200 == response.statusCode) {
        final List<User> users = userFromJson(response.body);
        return users;
      } else {
        return List<User>();
      }
    } catch (e) {
      return List<User>();
    }
  }
}
