import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_model/user_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserDetails {
  Future<void> saveUserDetails(UserModel userModel) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString("user", jsonEncode(userModel.toJson()));
  }

  Future<void> logoutUser() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    await sharedPreferences.remove("user");
  }

  Future<UserModel> get getSaveUserDetails async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    String userData = sharedPreferences.getString("user");
    if (userData == null) {
      return null;
    }
    log("message ==>  $userData");
    return UserModel.fromJson(jsonDecode(userData));
  }

  Future<void> saveTutorialShow({bool isTutorialShow = false}) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setBool("isTutorialShow", isTutorialShow);
  }

  Future<bool> get isTutorialShow async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    return sharedPreferences.getBool("isTutorialShow") ?? false;
  }
}
