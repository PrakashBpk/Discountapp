import 'package:RM_DAAPP/bm_JsonParseDemo.dart';
import 'package:RM_DAAPP/bm_Users.dart';
import 'package:RM_DAAPP/bm_dash.dart';
import 'package:RM_DAAPP/bm_userpage.dart';
import 'package:RM_DAAPP/rm_userpage.dart';
import 'package:http/http.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import '../flutter_flow/flutter_flow_theme.dart';
import '../flutter_flow/flutter_flow_util.dart';
import '../flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class RReviseWidgets extends StatefulWidget {
  final String iid;
  // const ReviseWidget({Key key}) : super(key: key);
  RReviseWidgets({Key key, this.iid}) : super(key: key);
  @override
  _RReviseWidgetsState createState() => _RReviseWidgetsState();
}

class _RReviseWidgetsState extends State<RReviseWidgets> {
  List<User> _users;
  bool _loading;
  TextEditingController bookingid;
  TextEditingController textController1;
  TextEditingController textController2;
  final scaffoldKey = GlobalKey<ScaffoldState>();

  Future update(String requestStatus, requestUpdatedOn) async {
    var url = "http://14.141.213.116:861/api/superRevisedUpdate.php";

    final response = await http.post(url, body: {
      //"booking_id": widget.iid,
      //"request_status": requeststatus,
      //"statuschangetime": statuschangetime,
      "request_booking_id": widget.iid,
      "request_revised_discount": textController1.text,
      "request_comments": textController2.text,
      "request_status": requestStatus,
      "request_updated_on": requestUpdatedOn,
    });
    var res = response.body;
    print(widget.iid);
  }

  @override
  void initState() {
    super.initState();
    bookingid = TextEditingController();
    textController1 = TextEditingController();
    textController2 = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    bookingid.text = widget.iid;
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.red,
        automaticallyImplyLeading: false,
        leading: InkWell(
          onTap: () async {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back_rounded,
            color: Colors.white,
            size: 24,
          ),
        ),
        title: Text(
          'Revise the Value',
          style: FlutterFlowTheme.subtitle1.override(
            fontFamily: 'Roboto',
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0,
      ),
      backgroundColor: Color(0xFFF7F7F8),
      body: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: Padding(
                          padding:
                              EdgeInsetsDirectional.fromSTEB(24, 16, 24, 8),
                          child: TextFormField(
                            controller: bookingid,
                            obscureText: false,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: 'Booking ID',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              hintText: '.',
                              hintStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: Padding(
                          padding:
                              EdgeInsetsDirectional.fromSTEB(24, 16, 24, 8),
                          child: TextFormField(
                            controller: textController1,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: 'New Value',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              hintText: '.',
                              hintStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(24, 0, 26, 2),
                          child: TextFormField(
                            controller: textController2,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: 'Comment',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            maxLines: 5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                  child: FFButtonWidget(
                    onPressed: () {
                      setState(() {
                        DateTime dateToday = new DateTime.now();
                        String requestUpdatedOn =
                            dateToday.toString().substring(0, 10);
                        print(widget.iid);
                        update("2", requestUpdatedOn);
                        // denied();
                        Navigator.of(context)
                            .push(
                              MaterialPageRoute(
                                  builder: (BuildContext context) =>
                                      UserWidget()),
                            )
                            .then((users) => setState(() {
                                  _users = users;
                                  _loading = true;
                                }));
                      });
                    },
                    text: 'Submit',
                    options: FFButtonOptions(
                      width: 230,
                      height: 50,
                      color: Colors.red,
                      textStyle: FlutterFlowTheme.subtitle2.override(
                        fontFamily: 'Roboto',
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      elevation: 8,
                      borderSide: BorderSide(
                        color: Colors.transparent,
                        width: 1,
                      ),
                      borderRadius: 8,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
