import 'package:RM_DAAPP/bm_model/user_model.dart';
import 'package:RM_DAAPP/bm_other/userDetails.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/bm_admin_dash.dart';
import 'package:RM_DAAPP/approved_details/approved_details_widget.dart';
import 'package:RM_DAAPP/bm_model/pending_view_model.dart';
import 'package:RM_DAAPP/bm_other/common.dart';
import 'package:RM_DAAPP/bm_widget/user_data_widget.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'bm_approved_details/deniedResubmit.dart';
import 'bm_deniedinfo.dart';
import 'bm_details.dart';
import 'bm_flutter_flow/flutter_flow_theme.dart';
import 'bm_newdata.dart';

/* void main() => runApp(MaterialApp(
      title: "Api Test",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: adminDash(),
    )); */

class DeniedDetails extends StatefulWidget {
  @override
  _DeniedDetailsState createState() => _DeniedDetailsState();
}

class _DeniedDetailsState extends State<DeniedDetails> {
  UserDetails userDetails = UserDetails();
  Future<List<PendingViewModel>> getPendingData() async {
    List<PendingViewModel> pendingList = [];
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var url =
          "http://118.91.235.247/daapp/api/admin_denied_view.php?admin_id=${userModel.userId}";
      var response = await http.get(url);

      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Denied List"),
        backgroundColor: Colors.red,
      ),
      /*  floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (BuildContext contex) => NewData(),
          ),
        ),
        child: Icon(Icons.add),
      ), */
      body: FutureBuilder(
        future: getPendingData(),
        builder: (cont, AsyncSnapshot<List<PendingViewModel>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return Container(
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.data == null || snapshot.data.isEmpty) {
            return Container(
              child: Center(
                child: Text(
                  "Record not found...",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
            );
          }

          return ListView.builder(
              itemCount: snapshot.data.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                PendingViewModel pendingViewModel = snapshot.data[index];
                return InkWell(
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DeniedInfoWidget(
                          pendingViewModel: pendingViewModel,
                        ),
                      ),
                    );
                  },
                  child: UserDataWidget(
                    pendingViewModel: pendingViewModel,
                  ),
                );
              });
        },
      ),
    );
  }
}
