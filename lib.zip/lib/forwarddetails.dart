import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/JsonParseDemo.dart';
import 'package:RM_DAAPP/admin_dash.dart';
import 'package:RM_DAAPP/approvedViewDetails.dart';
import 'package:RM_DAAPP/forwardlist.dart';
import 'package:RM_DAAPP/model/pending_view_model.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/widget/user_data_widget.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'approved_details/approved_details_widget.dart';
import 'details.dart';
import 'flutter_flow/flutter_flow_theme.dart';
import 'newdata.dart';

/* void main() => runApp(MaterialApp(
      title: "Api Test",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: adminDash(),
    )); */

class ForwardDetails extends StatefulWidget {
  @override
  _ForwardDetailsState createState() => _ForwardDetailsState();
}

class _ForwardDetailsState extends State<ForwardDetails> {
  Future<List<PendingViewModel>> getPendingData(String userId) async {
    List<PendingViewModel> pendingList = [];
    try {
      var url =
          "http://118.91.235.247/daapp/api/admin_forward_view.php?admin_id=$userId";
      var response = await http.get(url);

      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Forward Lists"),
        //backgroundColor: Colors.transparent,
        //elevation: 0,
        backgroundColor: Colors.red,
      ),
      /*   floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (BuildContext contex) => JsonParseDemo(),
          ),
        ),
        child: Icon(Icons.add),
      ), */
      body: FutureBuilder(
        future: getPendingData(userData.userId),
        builder: (cont, AsyncSnapshot<List<PendingViewModel>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return Container(
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.data == null || snapshot.data.isEmpty) {
            return Container(
              child: Center(
                child: Text(
                  "Record not found...",
                  style: TextStyle(
                      color: Colors.grey,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
            );
          }

          return ListView.builder(
              itemCount: snapshot.data.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                PendingViewModel pendingViewModel = snapshot.data[index];
                return InkWell(
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => ApprovedDetailsWidget(
                          pendingViewModel: pendingViewModel,
                        ),
                      ),
                    );
                  },
                  child: UserDataWidget(
                    pendingViewModel: pendingViewModel,
                  ),
                );
              });
        },
      ),
    );
  }
}

class approvedItems extends StatelessWidget {
  List list;

  approvedItems({this.list});
  var name;
  @override
  Widget build(BuildContext context) {
    // print(list.length);
    // Text("");

    return ListView.builder(
        itemCount: list == null ? 0 : list.length,
        itemBuilder: (ctx, i) {
          String approved = ('${list.length}');
          print(approved);
          //   new  return Text(data)
          return GestureDetector(
              onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          Forward(list: list, index: i),
                    ),
                  ),
              child: Card(
                clipBehavior: Clip.antiAliasWithSaveLayer,
                color: Color(0xFFF5F5F5),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['id'],
                            style: FlutterFlowTheme.subtitle2.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(170, 5, 0, 0),
                          child: Text(
                            list[i]['requestdate'],
                            style: FlutterFlowTheme.bodyText1,
                          ),
                        )
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['name'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['carmodel'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),
                        /*   Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                      child: Text(
                        list[i]['salesexcutivename'],
                        style: FlutterFlowTheme.bodyText1.override(
                          fontFamily: 'Roboto',
                        ),
                      ),
                    ), */
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(10, 5, 0, 0),
                          child: Text(
                            list[i]['yearmake'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )
                      ],
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['discountvalue'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ));

          /* ListTile(
              //      leading:
              // title: Text(list[i]['name']),
              title: Text('${list.length}'),
              subtitle: Text(list[i]['salesexcutivename']),

              //subtitle: Text(list[i]['salesexcutivename']),
              onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          Approvedviewdetails(list: list, index: i),
                    ),
                  )); */
        });
  }
}
