import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_model/pending_view_model.dart';
import 'package:RM_DAAPP/rm_model/user_model.dart';
import 'package:RM_DAAPP/rm_other/common.dart';
import 'package:RM_DAAPP/rm_other/userDetails.dart';
import 'package:RM_DAAPP/rm_revise/revise_widget.dart';
import 'package:RM_DAAPP/rm_approved_details/approved_details_widget.dart';
import 'package:RM_DAAPP/rm_approved_details/rm_all_requests_details.dart';
import 'package:RM_DAAPP/rm_widget/user_data_widget.dart';

import '../RM_flutter_flow/flutter_flow_icon_button.dart';
import '../RM_flutter_flow/flutter_flow_theme.dart';
import '../RM_flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_session/flutter_session.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/smtp_server.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:email_auth/email_auth.dart';
import 'package:http/http.dart' as http;

class rmclosedDetails extends StatefulWidget {
  @override
  _rmclosedDetailsState createState() => _rmclosedDetailsState();
}

class _rmclosedDetailsState extends State<rmclosedDetails> {
  UserDetails userDetails = UserDetails();
  Future<List<PendingViewModel>> getPendingData() async {
    List<PendingViewModel> pendingList = [];
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var response = await http.get(
          "http://118.91.235.247/daapp/api/rm_closed_request_view.php?rmng_id=${userModel.userId}");
      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Closed Request"),
        backgroundColor: Colors.red,
      ),
      body: FutureBuilder(
        future: getPendingData(),
        builder: (cont, AsyncSnapshot<List<PendingViewModel>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return Container(
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.data == null || snapshot.data.isEmpty) {
            return Container(
              child: Center(
                child: Text(
                  "Record not found...",
                  style: TextStyle(
                      color: Colors.red,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
            );
          }

          return ListView.builder(
              itemCount: snapshot.data.length,
              shrinkWrap: true,
              // physics: NeverScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                PendingViewModel pendingViewModel = snapshot.data[index];
                return InkWell(
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => rmallrquests(
                          pendingViewModel: pendingViewModel,
                        ),
                      ),
                    ).then((value) {
                      setState(() {});
                    });
                  },
                  child: UserDataWidget(
                    pendingViewModel: pendingViewModel,
                    // onDelete: () {
                    // deletePendingData(
                    //     userData.userId, pendingViewModel.bookId);
                    // },
                  ),
                );
              });
        },
      ),
    );
  }
}
