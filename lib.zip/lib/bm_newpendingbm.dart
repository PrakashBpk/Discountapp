/* import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/admin_dash.dart';
import 'package:RM_DAAPP/approved_details/admin_approved_details_widget.dart';
import 'package:RM_DAAPP/editdata.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/widget/user_data_widget.dart';
import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

import 'JsonParseDemo.dart';
import 'Users.dart';
import 'approved_details/approved_details_widget.dart';
import 'details.dart';
import 'flutter_flow/flutter_flow_theme.dart';
import 'flutter_flow/flutter_flow_widgets.dart';
import 'model/pending_view_model.dart';
import 'newdata.dart';

class newpendingbm extends StatefulWidget {
  @override
  _newpendingbmState createState() => _newpendingbmState();
}

class _newpendingbmState extends State<newpendingbm> {
  Future<List<PendingViewModel>> getPendingData(String userId) async {
    List<PendingViewModel> pendingList = [];
    try {
      // var response = await http.get(
      //     "http://118.91.235.247/daapp/api/admin_pending_view.php?admin_id=${userData.userId}");
      // if (response.statusCode == 200) {
      //   pendingList = pendingViewModelFromJson(response.body);
      // }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  Widget build(BuildContext context) {
    var choiceAction;
    var orientation;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFF09A74),
        automaticallyImplyLeading: true,
        title: Text(
          'PENDING',
          style: FlutterFlowTheme.title1.override(
            fontFamily: 'Roboto',
            color: FlutterFlowTheme.tertiaryColor,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
      backgroundColor: Color(0xFFEBA889),
      body: SafeArea(
        child: Column(mainAxisSize: MainAxisSize.max, children: [
          Expanded(
            child: DefaultTabController(
              length: 2,
              initialIndex: 0,
              child: Column(
                children: [
                  TabBar(
                    isScrollable: true,
                    labelColor: Colors.white,
                    labelStyle: FlutterFlowTheme.title2.override(
                      fontFamily: 'Roboto',
                    ),
                    indicatorColor: Colors.white,
                    tabs: [
                      Tab(
                        text: 'WITHIN LIMIT',
                      ),
                      Tab(
                        text: 'EXCEEDING LIMIT',
                      )
                    ],
                  ),
                  Expanded(
                      child: TabBarView(children: [
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: Colors.white,
                      ),
                      
                    ),
                  ]))
                ],
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
 */
import 'dart:async';
import 'dart:developer';

import 'package:RM_DAAPP/bm_model/user_model.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/bm_Login.dart';
import 'package:RM_DAAPP/bm_approved_details/admin_approved_details_widget.dart';
import 'package:RM_DAAPP/bm_approveddetails.dart';
import 'package:RM_DAAPP/bmPendingWithLimit.dart';
import 'package:RM_DAAPP/bmPendingWithoutLimit.dart';
import 'package:RM_DAAPP/bm_flutter_flow/flutter_flow_theme.dart';
import 'package:RM_DAAPP/bm_flutter_flow/flutter_flow_widgets.dart';
import 'package:RM_DAAPP/bm_model/dashBoardModel.dart';
import 'package:RM_DAAPP/bm_model/pending_view_model.dart';
import 'package:RM_DAAPP/bm_other/common.dart';
import 'package:RM_DAAPP/bm_other/userDetails.dart';
import 'package:RM_DAAPP/bm_pending_user/pending_user_widget.dart';
import 'package:RM_DAAPP/bm_widget/user_data_widget.dart';
import 'package:flutter/src/widgets/framework.dart';

import 'package:http/http.dart' as http;

import 'flutter_flow/flutter_flow_util.dart';

class TabbedAppBarSample extends StatefulWidget {
  @override
  _TabbedAppBarSampleState createState() => _TabbedAppBarSampleState();

  //static getPendngData(String userId) {}
}

class _TabbedAppBarSampleState extends State<TabbedAppBarSample> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  Timer timer;
  UserDetails userDetails = UserDetails();
  bool _loading;
  List<DashBoardModel> _users;
  DashBoardModel _dashBoardModel = DashBoardModel();
  /*  Future<List<PendingViewModel>> getPendingData(String userId) async {
    List<PendingViewModel> pendingList = [];
    try {
      var response = await http.get(
          "http://118.91.235.247/daapp/api/admin_pending_view.php?admin_id=${userData.userId}");
      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  } */

//class TabbedAppBarSampleState {
  Future getDashBoardData() async {
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var url =
          "http://118.91.235.247/daapp/api/admin_pending_dash.php?admin_id=${userModel.userId}";
      var response = await http.get(url);

      log("response ===>   ${response.body}");
      if (response.statusCode == 200) {
        _dashBoardModel = dashBoardModelFromJson(response.body);
        setState(() {});
      }
    } catch (e) {
      _dashBoardModel = DashBoardModel();
    }
  }

  @override
  void initState() {
    super.initState();
    getDashBoardData();
    /*  main();
    timer = Timer.periodic(Duration(seconds: 2), (Timer t) => JsonParseDemo()); */
    // _existingCustomer.add(PendingModel(statusName: "Yes", statusId: "1"));
    //_existingCustomer.add(PendingModel(statusName: "No", statusId: "0"));
    // getBranch();
    /// getCarmodel();
    /// getCurrentOffer();
    /// getCarColor();
    // getYearMake();
    // getDashBoardData();
    // salesExecutiveController.text = userData.userName;
    timer = Timer.periodic(
      Duration(seconds: 3),
      (Timer t) => getDashBoardData().then((users) {
        setState(() {
          _users = users;

          _loading = false;
        });
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          automaticallyImplyLeading: true,
          title: Text(
            'PENDING',
            style: FlutterFlowTheme.title1.override(
              fontFamily: 'Roboto',
              color: FlutterFlowTheme.tertiaryColor,
              fontWeight: FontWeight.w800,
            ),
          ),
          centerTitle: true,
          elevation: 4,
        ),
        //  backgroundColor: Color(0xFFEBA889),
        //  body: SafeArea(
        key: scaffoldKey,
        backgroundColor: Color(0xFFF5F5F5),
        body: SafeArea(
          /// child: Column(children: [],),
          child: Container(
            width: 1000,
            height: 1000,
            decoration: BoxDecoration(
              color: Color(0xFFEEEEEE),
            ),
            child: GridView(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1,
                ),
                scrollDirection: Axis.vertical,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                    child: InkWell(
                      onTap: () async {
                        // await Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //     builder: (context) =>
                        //         PendingUserWidget(),
                        //   ),
                        // );
                        await Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.fade,
                            duration: Duration(milliseconds: 0),
                            reverseDuration: Duration(milliseconds: 0),
                            child: bmPendingWithLimitDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: Color(0xE8E9A6DE),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.attach_money_outlined,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'WITHIN LIMIT',
                                    style: FlutterFlowTheme.title3.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_dashBoardModel.count.withlimit ?? ""}',
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 15, 5, 0),
                    child: InkWell(
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) =>
                                bmPendingWithoutLimitDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: Color(0xFFF48FB1),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.attach_money_outlined,
                                  color: FlutterFlowTheme.tertiaryColor,
                                  size: 50,
                                )
                              ],
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'ABOVE LIMIT',
                                    style: FlutterFlowTheme.title3.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_dashBoardModel.count.abovelimit ?? ""}',
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ]),
          ),
        ));
  }
}
