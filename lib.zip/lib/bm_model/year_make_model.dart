import 'dart:convert';

List<YearMakeModel> yearMakeModelFromJson(String str) => List<YearMakeModel>.from(json.decode(str).map((x) => YearMakeModel.fromJson(x)));

String yearMakeModelToJson(List<YearMakeModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class YearMakeModel {
  YearMakeModel({
    this.yearMakeId,
    this.yearMakeName,
  });

  String yearMakeId;
  String yearMakeName;

  factory YearMakeModel.fromJson(Map<String, dynamic> json) => YearMakeModel(
    yearMakeId: json["year_make_id"],
    yearMakeName: json["year_make_name"],
  );

  Map<String, dynamic> toJson() => {
    "year_make_id": yearMakeId,
    "year_make_name": yearMakeName,
  };
}
