import 'dart:convert';

DashBoardModel dashBoardModelFromJson(String str) =>
    DashBoardModel.fromJson(json.decode(str));

String dashBoardModelToJson(DashBoardModel data) => json.encode(data.toJson());

class DashBoardModel {
  DashBoardModel({
    this.count,
    this.response,
  }) {
    if (count == null) {
      count = Count();
    }
  }

  Count count;
  String response;

  factory DashBoardModel.fromJson(Map<String, dynamic> json) => DashBoardModel(
        count: json["count"] != null ? Count.fromJson(json["count"]) : Count(),
        response: json["response"],
      );

  Map<String, dynamic> toJson() => {
        "count": count.toJson(),
        "response": response,
      };
}

class Count {
  Count({
    this.pending = "0",
    this.approved = "0",
    this.revised = "0",
    this.forward = "0",
    this.delete = "0",
    this.withlimit = "0",
    this.abovelimit = "0",
  });

  String pending;
  String approved;
  String revised;
  String forward;
  String delete;
  String withlimit;
  String abovelimit;

  factory Count.fromJson(Map<String, dynamic> json) => Count(
        pending: json["pending"] ?? "0",
        approved: json["approved"] ?? "0",
        revised: json["revised"] ?? "0",
        withlimit: json["withlimit"] ?? "0",
        abovelimit: json["abovelimit"] ?? "0",
        forward: json["forward"] ?? "0",
        delete: json["delete"] ?? json["denied"] ?? "0",
      );

  Map<String, dynamic> toJson() => {
        "pending": pending,
        "approved": approved,
        "revised": revised,
        "forward": forward,
        "delete": delete,
        'abovelimit': abovelimit,
        'withlimit': withlimit,
      };
}
