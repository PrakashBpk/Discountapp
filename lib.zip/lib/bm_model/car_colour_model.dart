import 'dart:convert';

List<CarColourModel> carColourModelFromJson(String str) => List<CarColourModel>.from(json.decode(str).map((x) => CarColourModel.fromJson(x)));

String carColourModelToJson(List<CarColourModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CarColourModel {
  CarColourModel({
    this.carColorId,
    this.carColorName,
  });

  String carColorId;
  String carColorName;

  factory CarColourModel.fromJson(Map<String, dynamic> json) => CarColourModel(
    carColorId: json["car_color_id"],
    carColorName: json["car_color_name"],
  );

  Map<String, dynamic> toJson() => {
    "car_color_id": carColorId,
    "car_color_name": carColorName,
  };
}
