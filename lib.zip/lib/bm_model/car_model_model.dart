import 'dart:convert';

List<CarModelModel> carModelModelFromJson(String str) => List<CarModelModel>.from(json.decode(str).map((x) => CarModelModel.fromJson(x)));

String carModelModelToJson(List<CarModelModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CarModelModel {
  CarModelModel({
    this.carModelId,
    this.carModelName,
  });

  String carModelId;
  String carModelName;

  factory CarModelModel.fromJson(Map<String, dynamic> json) => CarModelModel(
    carModelId: json["car_model_id"],
    carModelName: json["car_model_name"],
  );

  Map<String, dynamic> toJson() => {
    "car_model_id": carModelId,
    "car_model_name": carModelName,
  };
}
