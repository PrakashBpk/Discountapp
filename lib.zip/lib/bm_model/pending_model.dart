class PendingModel {
  String statusName;
  String statusId;
  String referrerStatus;
  String referrerId;

  PendingModel(
      {this.statusName, this.statusId, this.referrerStatus, this.referrerId});
}
