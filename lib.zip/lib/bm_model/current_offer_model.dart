import 'dart:convert';

List<CurrentOfferModel> currentOfferModelFromJson(String str) => List<CurrentOfferModel>.from(json.decode(str).map((x) => CurrentOfferModel.fromJson(x)));

String currentOfferModelToJson(List<CurrentOfferModel> data) => json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class CurrentOfferModel {
  CurrentOfferModel({
    this.offerId,
    this.offerName,
  });

  String offerId;
  String offerName;

  factory CurrentOfferModel.fromJson(Map<String, dynamic> json) => CurrentOfferModel(
    offerId: json["offer_id"],
    offerName: json["offer_name"],
  );

  Map<String, dynamic> toJson() => {
    "offer_id": offerId,
    "offer_name": offerName,
  };
}
