import 'dart:async';

import 'package:RM_DAAPP/bm_JsonParseDemo.dart';
import 'package:RM_DAAPP/bm_userpage.dart';
import 'package:RM_DAAPP/loginchoice.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/JsonParseDemo.dart';
import 'package:RM_DAAPP/flutter_flow/flutter_flow_theme.dart';
import 'package:RM_DAAPP/model/user_model.dart';
import 'package:RM_DAAPP/other/common.dart';
import 'package:RM_DAAPP/other/userDetails.dart';
import 'package:RM_DAAPP/userlogin.dart';
import 'package:RM_DAAPP/userpage.dart';

import 'Login.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  UserDetails userDetails = UserDetails();

  @override
  void initState() {
    super.initState();

    Timer(Duration(seconds: 3), () async {
      UserModel userModel = await userDetails.getSaveUserDetails;
      if (userModel != null) {
        if (userModel != null) {
          userData = userModel;
          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return loginchoicescreen();
          }), (route) => false);
        } else {
          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return loginchoicescreen();
            ;
          }), (route) => false);
        }
      } else {
        Navigator.pushAndRemoveUntil(context,
            MaterialPageRoute(builder: (context) {
          return loginchoicescreen();
        }), (route) => false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FlutterFlowTheme.tertiaryColor,
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 1,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              blurRadius: 700,
              color: Color(0xE8E79D8C),
              spreadRadius: 10000,
            )
          ],
          gradient: LinearGradient(
            colors: [Colors.red, Color(0xE8E9A6DE), Colors.white],
            stops: [1, 1, 1],
            begin: AlignmentDirectional(1, 0.34),
            end: AlignmentDirectional(-1, -0.34),
          ),
        ),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 60, 0, 0),
                child: Text(
                  'DAAPP',
                  style: FlutterFlowTheme.title1.override(
                    fontFamily: 'Roboto',
                    color: FlutterFlowTheme.tertiaryColor,
                    fontSize: 40,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
/* 
class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  UserDetails userDetails = UserDetails();

  @override
  void initState() {
    super.initState();

    Timer(Duration(seconds: 3), () async {
      UserModel userModel = await userDetails.getSaveUserDetails;
      if (userModel != null) {
        if (userModel != null) {
          userData = userModel;
          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return userModel.userRole != "Admin"
                ? UserWidget()
                : JsonParseDemo();
          }), (route) => false);
        }
        else if (userModel != null) {
          userData = userModel;
          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return userModel.userRole != "User"
                ? UserWidget()
                : JsonParseDemo();
          }), (route) => false);
        } else {
          Navigator.pushAndRemoveUntil(context,
              MaterialPageRoute(builder: (context) {
            return UserLoginWidget();
          }), (route) => false);
        }
      } else {
        Navigator.pushAndRemoveUntil(context,
            MaterialPageRoute(builder: (context) {
          return UserLoginWidget();
        }), (route) => false);
      }
    });
  }
 */