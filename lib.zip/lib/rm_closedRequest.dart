import 'dart:async';
import 'dart:developer';

import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_model/pending_view_model.dart';
import 'package:RM_DAAPP/rm_other/common.dart';
import 'package:RM_DAAPP/rm_pendingoutoftimedetails.dart';
import 'package:RM_DAAPP/rm_revise/revise_widget.dart';
import 'package:RM_DAAPP/rm_approved_details/approved_details_widget.dart';
import 'package:RM_DAAPP/rm_bmPendingWithLimit.dart';
import 'package:RM_DAAPP/rm_bmPendingWithoutLimit.dart';
import 'package:RM_DAAPP/rm_model/dashBoardModel.dart';
import 'package:RM_DAAPP/rm_widget/user_data_widget.dart';
import 'package:RM_DAAPP/rmapprovedin.dart';
import 'package:RM_DAAPP/rmapprovedout.dart';
import 'package:RM_DAAPP/rmpendingin.dart';
import 'package:RM_DAAPP/rmpendingout.dart';

import '../RM_flutter_flow/flutter_flow_icon_button.dart';
import '../RM_flutter_flow/flutter_flow_theme.dart';
import '../RM_flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_session/flutter_session.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/smtp_server.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:email_auth/email_auth.dart';
import 'package:http/http.dart' as http;

class rmClosedRequest extends StatefulWidget {
  @override
  _rmClosedRequestState createState() => _rmClosedRequestState();

  //static getPendngData(String userId) {}
}

class _rmClosedRequestState extends State<rmClosedRequest> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  Timer timer;
  bool _loading;
  List<DashBoardModel> _users;
  DashBoardModel _dashBoardModel = DashBoardModel();

  Future getDashBoardData() async {
    try {
      var url =
          "http://118.91.235.247/daapp/api/rmng_Sla_dash.php?rmng_id=${userData.userId}";
      var response = await http.get(url);

      log("response ===>   ${response.body}");
      if (response.statusCode == 200) {
        _dashBoardModel = dashBoardModelFromJson(response.body);
        setState(() {});
      }
    } catch (e) {
      _dashBoardModel = DashBoardModel();
    }
  }

  @override
  void initState() {
    super.initState();
    getDashBoardData();
    /*  main();
    timer = Timer.periodic(Duration(seconds: 2), (Timer t) => JsonParseDemo()); */
    // _existingCustomer.add(PendingModel(statusName: "Yes", statusId: "1"));
    //_existingCustomer.add(PendingModel(statusName: "No", statusId: "0"));
    // getBranch();
    /// getCarmodel();
    /// getCurrentOffer();
    /// getCarColor();
    // getYearMake();
    // getDashBoardData();
    // salesExecutiveController.text = userData.userName;
    timer = Timer.periodic(
      Duration(seconds: 3),
      (Timer t) => getDashBoardData().then((users) {
        setState(() {
          _users = users;

          _loading = false;
        });
      }),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          automaticallyImplyLeading: true,
          title: Text(
            'Closed Request',
            style: FlutterFlowTheme.title1.override(
              fontFamily: 'Roboto',
              color: FlutterFlowTheme.tertiaryColor,
              fontWeight: FontWeight.w800,
            ),
          ),
          centerTitle: true,
          elevation: 4,
        ),
        //  backgroundColor: Color(0xFFEBA889),
        //  body: SafeArea(
        key: scaffoldKey,
        backgroundColor: Color(0xFFF5F5F5),
        body: SafeArea(
          /// child: Column(children: [],),
          child: Container(
            width: 1000,
            height: 1000,
            decoration: BoxDecoration(
              color: Color(0xFFEEEEEE),
            ),
            child: GridView(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 4,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1,
                ),
                scrollDirection: Axis.vertical,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                    child: InkWell(
                      onTap: () async {
                        // await Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //     builder: (context) =>
                        //         PendingUserWidget(),
                        //   ),
                        // );
                        await Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.fade,
                            duration: Duration(milliseconds: 0),
                            reverseDuration: Duration(milliseconds: 0),
                            child: rmApprovedINDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: Color(0xFFF48FB1),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.check_circle,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Approved in Time',
                                    style: FlutterFlowTheme.title3.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_dashBoardModel.count.withlimit ?? ""}',
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(0, 15, 5, 0),
                    child: InkWell(
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => rmApprovedoutDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: Color(0xE8E9A6DE),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Row(
                              mainAxisSize: MainAxisSize.max,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.lock_clock_sharp,
                                  color: FlutterFlowTheme.tertiaryColor,
                                  size: 50,
                                )
                              ],
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Approved Out Time',
                                    style: FlutterFlowTheme.title3.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_dashBoardModel.count.abovelimit ?? ""}',
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.w800,
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                    child: InkWell(
                      onTap: () async {
                        // await Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //     builder: (context) =>
                        //         PendingUserWidget(),
                        //   ),
                        // );
                        await Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.fade,
                            duration: Duration(milliseconds: 0),
                            reverseDuration: Duration(milliseconds: 0),
                            child: bmPendingWithLimitDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: Colors.greenAccent[200],
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.forward,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Denied in Time',
                                    style: FlutterFlowTheme.title3.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_dashBoardModel.count.withlimit ?? ""}',
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(5, 15, 0, 0),
                    child: InkWell(
                      onTap: () async {
                        // await Navigator.push(
                        //   context,
                        //   MaterialPageRoute(
                        //     builder: (context) =>
                        //         PendingUserWidget(),
                        //   ),
                        // );
                        await Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.fade,
                            duration: Duration(milliseconds: 0),
                            reverseDuration: Duration(milliseconds: 0),
                            child: bmPendingWithLimitDetails(),
                          ),
                        ).then((value) => getDashBoardData());
                      },
                      child: Card(
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        color: Color(0xE8B8C8E4),
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 30, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.arrow_forward_ios_outlined,
                                    color: FlutterFlowTheme.tertiaryColor,
                                    size: 50,
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 5, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    'Denied out Time',
                                    style: FlutterFlowTheme.title3.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Padding(
                              padding:
                                  EdgeInsetsDirectional.fromSTEB(0, 10, 0, 0),
                              child: Row(
                                mainAxisSize: MainAxisSize.max,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    '${_dashBoardModel.count.withlimit ?? ""}',
                                    style: FlutterFlowTheme.bodyText1.override(
                                      fontFamily: 'Roboto',
                                      color: FlutterFlowTheme.tertiaryColor,
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  )
                                ],
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  ),
                ]),
          ),
        ));
  }
}
