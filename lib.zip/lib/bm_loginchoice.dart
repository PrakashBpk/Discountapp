import 'dart:async';

import 'package:RM_DAAPP/bm_flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:RM_DAAPP/bm_JsonParseDemo.dart';
import 'package:RM_DAAPP/bm_flutter_flow/flutter_flow_theme.dart';
import 'package:RM_DAAPP/bm_model/user_model.dart';
import 'package:RM_DAAPP/bm_other/common.dart';
import 'package:RM_DAAPP/bm_other/userDetails.dart';
import 'package:RM_DAAPP/bm_userlogin.dart';
import 'package:RM_DAAPP/bm_userpage.dart';

import 'bm_Login.dart';

class loginchoicescreen extends StatefulWidget {
  @override
  _loginchoiceState createState() => _loginchoiceState();
}

class _loginchoiceState extends State<loginchoicescreen> {
  UserDetails userDetails = UserDetails();

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: FlutterFlowTheme.tertiaryColor,
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height * 1,
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              blurRadius: 700,
              color: Colors.white,
              spreadRadius: 10000,
            )
          ],
          gradient: LinearGradient(
            colors: [Colors.red, Color(0xE8E9A6DE), Colors.white],
            stops: [1, 1, 1],
            begin: AlignmentDirectional(1, 0.34),
            end: AlignmentDirectional(-1, -0.34),
          ),
        ),
        child: Padding(
          padding: EdgeInsetsDirectional.fromSTEB(20, 0, 20, 0),
          child: Column(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Row(
                mainAxisSize: MainAxisSize.max,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(40, 0, 0, 0),
                    child: Text(
                      'Welcome to Daapp',
                      style: FlutterFlowTheme.title1.override(
                        fontFamily: 'Roboto',
                        color: FlutterFlowTheme.tertiaryColor,
                        fontSize: 30,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                //  mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(10, 80, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => UserLoginWidget(),
                          ),
                        ).then((value) {
                          setState(() {});
                        });
                      },
                      text: 'SalesRep',
                      options: FFButtonOptions(
                        width: 230,
                        height: 50,
                        color: Color(0xFFFFFFFF),
                        textStyle: FlutterFlowTheme.subtitle2.override(
                          fontFamily: 'Roboto',
                          color: Colors.red,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        elevation: 8,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: 100,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                //  mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(60, 30, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => UserLoginWidget(),
                          ),
                        ).then((value) {
                          setState(() {});
                        });
                      },
                      text: 'BM',
                      options: FFButtonOptions(
                        width: 230,
                        height: 50,
                        color: Colors.red,
                        textStyle: FlutterFlowTheme.subtitle2.override(
                          fontFamily: 'Roboto',
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        elevation: 8,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: 100,
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                //  mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.fromSTEB(110, 30, 0, 0),
                    child: FFButtonWidget(
                      onPressed: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => UserLoginWidget(),
                          ),
                        ).then((value) {
                          setState(() {});
                        });
                      },
                      text: 'RM',
                      options: FFButtonOptions(
                        width: 230,
                        height: 50,
                        color: Colors.red,
                        textStyle: FlutterFlowTheme.subtitle2.override(
                          fontFamily: 'Roboto',
                          color: Colors.white,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                        elevation: 8,
                        borderSide: BorderSide(
                          color: Colors.transparent,
                          width: 1,
                        ),
                        borderRadius: 100,
                      ),
                    ),
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsetsDirectional.fromSTEB(0, 150, 0, 0),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Powered by ABT Maruti',
                      style: FlutterFlowTheme.bodyText1.override(
                        fontFamily: 'Roboto',
                        color: Colors.black,
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                        fontStyle: FontStyle.italic,
                      ),
                    )
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
