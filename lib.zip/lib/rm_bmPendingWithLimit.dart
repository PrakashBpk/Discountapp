import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_model/pending_view_model.dart';
import 'package:RM_DAAPP/rm_model/user_model.dart';
import 'package:RM_DAAPP/rm_other/common.dart';
import 'package:RM_DAAPP/rm_other/userDetails.dart';
import 'package:RM_DAAPP/rm_revise/revise_widget.dart';
import 'package:RM_DAAPP/rm_approvedViewDetails.dart';
import 'package:RM_DAAPP/rm_approved_details/approved_details_widget.dart';
import 'package:RM_DAAPP/rm_approved_details/bmoperations.dart';
import 'package:RM_DAAPP/rm_widget/user_data_widget.dart';

import '../RM_flutter_flow/flutter_flow_icon_button.dart';
import '../RM_flutter_flow/flutter_flow_theme.dart';
import '../RM_flutter_flow/flutter_flow_util.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_session/flutter_session.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mailer/smtp_server.dart';
import 'package:flutter_svg/svg.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';
import 'package:email_auth/email_auth.dart';
import 'package:http/http.dart' as http;

class bmPendingWithLimitDetails extends StatefulWidget {
  @override
  _bmPendingWithLimitDetailsState createState() =>
      _bmPendingWithLimitDetailsState();
}

class _bmPendingWithLimitDetailsState extends State<bmPendingWithLimitDetails> {
  UserDetails userDetails = UserDetails();
  Future<List<PendingViewModel>> getPendingData() async {
    List<PendingViewModel> pendingList = [];
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var url =
          "http://118.91.235.247/daapp/api/rmng_pending_view_SLA.php?rmng_id=${userModel.userId}";
      var response = await http.get(url);
      log("response ==>   ${response.body}");
      if (response.statusCode == 200) {
        pendingList = pendingViewModelFromJson(response.body);
      }
    } catch (e) {
      pendingList = [];
    }
    return pendingList;
  }

  @override
  void initState() {
    super.initState();
    //getDashBoardData();
    /*  main();
    timer = Timer.periodic(Duration(seconds: 2), (Timer t) => JsonParseDemo()); */
    // _existingCustomer.add(PendingModel(statusName: "Yes", statusId: "1"));
    // _existingCustomer.add(PendingModel(statusName: "No", statusId: "0"));
    // getBranch();
    // getCarmodel();
    // getCurrentOffer();
    // getCarColor();
    // getYearMake();
    // getDashBoardData();
    // salesExecutiveController.text = userData.userName;
    // timer = Timer.periodic(
    //   Duration(seconds: 3),
    //   (Timer t) => getDashBoardData().then((users) {
    //     setState(() {
    //       _users = users;

    //       _loading = false;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("With Limit Lists"),
        backgroundColor: Colors.red,
      ),
      /*   floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(
            builder: (BuildContext contex) => JsonParseDemo(),
          ),
        ),
        child: Icon(Icons.add),
      ), */
      body: FutureBuilder(
        future: getPendingData(),
        builder: (cont, AsyncSnapshot<List<PendingViewModel>> snapshot) {
          if (snapshot.connectionState != ConnectionState.done) {
            return Container(
              child: Center(child: CircularProgressIndicator()),
            );
          }

          if (snapshot.data == null || snapshot.data.isEmpty) {
            return Container(
              child: Center(
                child: Text(
                  "Record not found...",
                  style: TextStyle(
                      color: Colors.red,
                      fontSize: 16,
                      fontWeight: FontWeight.w600),
                ),
              ),
            );
          }

          return ListView.builder(
              itemCount: snapshot.data.length,
              shrinkWrap: true,
              itemBuilder: (context, index) {
                PendingViewModel pendingViewModel = snapshot.data[index];
                return InkWell(
                  onTap: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => rmWithinpendingDetailsWidget(
                          pendingViewModel: pendingViewModel,
                        ),
                      ),
                    );
                  },
                  child: UserDataWidget(
                    pendingViewModel: pendingViewModel,
                  ),
                );
              });
        },
      ),
    );
  }
}

class approvedItems extends StatelessWidget {
  List list;

  approvedItems({this.list});
  var name;
  @override
  Widget build(BuildContext context) {
    // print(list.length);
    // Text("");

    return ListView.builder(
        itemCount: list == null ? 0 : list.length,
        itemBuilder: (ctx, i) {
          String approved = ('${list.length}');
          print(approved);
          //   new  return Text(data)
          return GestureDetector(
              onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          Approvedviewdetails(list: list, index: i),
                    ),
                  ),
              child: Card(
                clipBehavior: Clip.antiAliasWithSaveLayer,
                color: Color(0xFFF5F5F5),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['id'],
                            style: FlutterFlowTheme.subtitle2.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),

                        // Padding(
                        //   padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                        //   child: Text(
                        //     list[i]['userName'],
                        //     style: FlutterFlowTheme.subtitle2.override(
                        //       fontFamily: 'Roboto',
                        //     ),
                        //   ),
                        // ),
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(170, 5, 0, 0),
                          child: Text(
                            list[i]['requestdate'],
                            style: FlutterFlowTheme.bodyText1,
                          ),
                        )
                      ],
                    ),

                    RichText(
                      text: TextSpan(text: "", children: [
                        WidgetSpan(
                            child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['name'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )),
                        WidgetSpan(
                            child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['carmodel'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )),
                        WidgetSpan(
                            child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['user_name'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )),
                        WidgetSpan(
                            child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(10, 5, 0, 0),
                          child: Text(
                            list[i]['yearmake'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )),
                      ]),
                    ),
                    // Row(
                    //   mainAxisSize: MainAxisSize.max,
                    //   children: [
                    //     Padding(
                    //       padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                    //       child: Text(
                    //         list[i]['name'],
                    //         style: FlutterFlowTheme.bodyText1.override(
                    //           fontFamily: 'Roboto',
                    //         ),
                    //       ),
                    //     ),
                    //     Padding(
                    //       padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                    //       child: Text(
                    //         list[i]['carmodel'],
                    //         style: FlutterFlowTheme.bodyText1.override(
                    //           fontFamily: 'Roboto',
                    //         ),
                    //       ),
                    //     ),
                    //     /*   Padding(
                    //   padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                    //   child: Text(
                    //     list[i]['salesexcutivename'],
                    //     style: FlutterFlowTheme.bodyText1.override(
                    //       fontFamily: 'Roboto',
                    //     ),
                    //   ),
                    // ), */
                    //     Padding(
                    //       padding: EdgeInsetsDirectional.fromSTEB(10, 5, 0, 0),
                    //       child: Text(
                    //         list[i]['yearmake'],
                    //         style: FlutterFlowTheme.bodyText1.override(
                    //           fontFamily: 'Roboto',
                    //         ),
                    //       ),
                    //     )
                    //   ],
                    // ),
                    Row(
                      mainAxisSize: MainAxisSize.max,
                      children: [
                        Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(5, 5, 0, 0),
                          child: Text(
                            list[i]['discountvalue'],
                            style: FlutterFlowTheme.bodyText1.override(
                              fontFamily: 'Roboto',
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ));

          /* ListTile(
              //      leading:
              // title: Text(list[i]['name']),
              title: Text('${list.length}'),
              subtitle: Text(list[i]['salesexcutivename']),

              //subtitle: Text(list[i]['salesexcutivename']),
              onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (BuildContext context) =>
                          Approvedviewdetails(list: list, index: i),
                    ),
                  )); */
        });
  }
}
