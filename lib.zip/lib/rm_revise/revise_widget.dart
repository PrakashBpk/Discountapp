import 'dart:convert';
import 'dart:developer';

import 'package:RM_DAAPP/rm_JsonParseDemo.dart';
import 'package:RM_DAAPP/rm_Users.dart';
import 'package:RM_DAAPP/rm_model/dashBoardModel.dart';
import 'package:RM_DAAPP/rm_model/pending_view_model.dart';
import 'package:RM_DAAPP/rm_model/user_model.dart';
import 'package:RM_DAAPP/rm_other/common.dart';
import 'package:RM_DAAPP/rm_other/userDetails.dart';
import 'package:page_transition/page_transition.dart';
//import 'package:RM_DAAPP/pending_user/pending_user_widget.dart';
//import 'package:RM_DAAPP/userpage.dart';

import '../RM_flutter_flow/flutter_flow_theme.dart';
import '../RM_flutter_flow/flutter_flow_widgets.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../RM_pendingdetails.dart';
import '../RM_userpage.dart';

class ReviseWidget extends StatefulWidget {
  PendingViewModel pendingViewModel;

  ReviseWidget({this.pendingViewModel});

  @override
  _ReviseWidgetState createState() => _ReviseWidgetState();
}

class _ReviseWidgetState extends State<ReviseWidget> {
  List<String> discounttype = ['Cash', 'Accessories'];
  String discounttyp;
  DashBoardModel _dashBoardModel = DashBoardModel();
  List<User> _users;
  UserDetails userDetails = UserDetails();
  bool _loading;
  TextEditingController bookingid;
  TextEditingController olddiscountvalue;
  TextEditingController textController1;
  TextEditingController textController2;
  final scaffoldKey = GlobalKey<ScaffoldState>();
  Future getDashBoardData() async {
    try {
      UserModel userModel = await userDetails.getSaveUserDetails;
      var url =
          "http://118.91.235.247/daapp/api/dashboard.php?user_id=${userModel.userId}";
      var response = await http.get(url);

      log("response ===> url ==>  $url   \n  ${response.body}");
      if (response.statusCode == 200) {
        _dashBoardModel = dashBoardModelFromJson(response.body);
        setState(() {});
      }
    } catch (e) {
      _dashBoardModel = DashBoardModel();
    }
  }

  Future update(String requestStatus, requestUpdatedOn) async {
    UserModel userModel = await userDetails.getSaveUserDetails;
    var url =
        "http://118.91.235.247/daapp/api/rm_revised.php?user_id=${userModel.userId}";

    final response = await http.post(url, body: {
      //"booking_id": widget.iid,
      //"request_status": requeststatus,
      //"statuschangetime": statuschangetime,
      "request_booking_id": widget.pendingViewModel.bookId,
      "request_revised_discount": textController1.text,
      "req_denied_comment": textController2.text,
      "request_status": requestStatus,
      "resumbit_discount_type": discounttyp,
      // "user_id": widget.pendingViewModel.userId,
      "request_updated_on": requestUpdatedOn,
    });
    var res = response.body;
    print(widget.pendingViewModel.bookId);
  }

  void discountchecklimit() {
    var oldvalue = int.parse(olddiscountvalue.text);
    var newvalue = int.parse(textController1.text);
    if (oldvalue >= newvalue) {
      print("value is smaller");
      DateTime dateToday = new DateTime.now();
      String requestUpdatedOn = dateToday.toString().substring(0, 10);
      update("4", requestUpdatedOn);
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text("Success"),
          content: Text("Revised Successfully"),
          actions: <Widget>[
            FlatButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              child: Text("okay"),
            ),
          ],
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text("Warnning"),
          content: Text("You Dont Enter above value"),
          actions: <Widget>[
            FlatButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              child: Text("okay"),
            ),
          ],
        ),
      );
      print("value is high");
    }
  }

  @override
  void initState() {
    super.initState();
    bookingid = TextEditingController();
    olddiscountvalue = TextEditingController();
    textController1 = TextEditingController();
    textController2 = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    bookingid.text = widget.pendingViewModel.bookId;
    olddiscountvalue.text = widget.pendingViewModel.discount;
    return Scaffold(
      key: scaffoldKey,
      appBar: AppBar(
        backgroundColor: Colors.red,
        automaticallyImplyLeading: false,
        leading: InkWell(
          onTap: () async {
            Navigator.pop(context);
          },
          child: Icon(
            Icons.arrow_back_rounded,
            color: Colors.white,
            size: 24,
          ),
        ),
        title: Text(
          'Revise the Value',
          style: FlutterFlowTheme.subtitle1.override(
            fontFamily: 'Roboto',
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.w500,
          ),
        ),
        actions: [],
        centerTitle: true,
        elevation: 0,
      ),
      backgroundColor: Color(0xFFF7F7F8),
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                          child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(24, 0, 26, 0),
                        child: Text("Booking ID      :",
                            style: TextStyle(
                              color: Colors.grey[800],
                              fontWeight: FontWeight.bold,
                            )),
                      )),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(4, 16, 24, 8),
                          child: TextFormField(
                            controller: bookingid,
                            obscureText: false,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: '',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              hintText: '.',
                              hintStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                          child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(24, 0, 26, 0),
                        child: Text("Discount Type :",
                            style: TextStyle(
                              color: Colors.grey[800],
                              fontWeight: FontWeight.bold,
                            )),
                      )),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(4, 0, 26, 0),
                          child: DropdownButton(
                            isExpanded: true,
                            hint: Text("Select Discount Type"),
                            value: discounttyp,
                            onTap: removeFocus,
                            icon: Icon(Icons.keyboard_arrow_down),
                            items: discounttype.map((String value) {
                              return DropdownMenuItem(
                                  value: value, child: Text(value ?? ""));
                            }).toList(),
                            onChanged: (s) {
                              discounttyp = s;
                              setState(() {});
                            },
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                          child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(24, 0, 26, 0),
                        child: Text("Old Discount      :",
                            style: TextStyle(
                              color: Colors.grey[800],
                              fontWeight: FontWeight.bold,
                            )),
                      )),
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(4, 16, 24, 8),
                          child: TextFormField(
                            controller: olddiscountvalue,
                            obscureText: false,
                            enabled: false,
                            decoration: InputDecoration(
                              labelText: '',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              hintText: '.',
                              hintStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 70,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: Padding(
                          padding:
                              EdgeInsetsDirectional.fromSTEB(24, 16, 24, 8),
                          child: TextFormField(
                            controller: textController1,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: ' New Value',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              hintText: '.',
                              hintStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            keyboardType: TextInputType.number,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),

            /* TextFormField(
                            controller: textController2,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: 'Comment',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            maxLines: 5,
                          ), */

            Row(
              mainAxisSize: MainAxisSize.max,
              children: [
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: 80,
                  decoration: BoxDecoration(
                    color: Colors.white,
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Expanded(
                        child: Padding(
                          padding: EdgeInsetsDirectional.fromSTEB(24, 0, 26, 2),
                          child: TextFormField(
                            controller: textController2,
                            obscureText: false,
                            decoration: InputDecoration(
                              labelText: 'Comment',
                              labelStyle: FlutterFlowTheme.bodyText2.override(
                                fontFamily: 'Roboto',
                                color: Color(0xFF8B97A2),
                                fontSize: 14,
                                fontWeight: FontWeight.normal,
                              ),
                              enabledBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              focusedBorder: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color: Color(0xFFDCE0E4),
                                  width: 2,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            style: FlutterFlowTheme.bodyText2.override(
                              fontFamily: 'Roboto',
                              color: Color(0xFF0F181F),
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.start,
                            maxLines: 5,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(0, 20, 0, 0),
                  child: FFButtonWidget(
                    onPressed: () {
                      setState(() {
                        DateTime dateToday = new DateTime.now();
                        String requestUpdatedOn =
                            dateToday.toString().substring(0, 10);
                        print(widget.pendingViewModel.bookId);
                        //update("4", requestUpdatedOn);
                        // denied();
                        //discountlimitcheck();
                        discountchecklimit();
                        Navigator.push(
                          context,
                          PageTransition(
                            type: PageTransitionType.fade,
                            duration: Duration(seconds: 4),
                            reverseDuration: Duration(seconds: 4),
                            child: rmJsonParseDemo(),
                          ),
                        ).then((value) => rmJsonParseDemo());

                        /*    Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  userReviseWidget()),
                        );*/
                      });
                    },
                    text: 'Submit',
                    options: FFButtonOptions(
                      width: 150,
                      height: 50,
                      color: Colors.blue[700],
                      textStyle: FlutterFlowTheme.subtitle2.override(
                        fontFamily: 'Roboto',
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                      elevation: 8,
                      borderSide: BorderSide(
                        color: Colors.transparent,
                        width: 1,
                      ),
                      borderRadius: 8,
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      )),
    );
  }

  void removeFocus() {
    FocusManager.instance.primaryFocus.unfocus();
  }

  String totalRequestCount() {
    int total = 0;
    if (_dashBoardModel != null) {
      try {
        total = total + int.parse(_dashBoardModel.count.pending);
      } catch (e) {}

      try {
        total = total + int.parse(_dashBoardModel.count.approved);
      } catch (e) {}

      try {
        total = total + int.parse(_dashBoardModel.count.delete);
      } catch (e) {}
      try {
        total = total + int.parse(_dashBoardModel.count.revised);
      } catch (e) {}
      try {
        total = total + int.parse(_dashBoardModel.count.forward);
      } catch (e) {}
    }
  }
}
